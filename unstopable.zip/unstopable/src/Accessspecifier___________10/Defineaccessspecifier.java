package Accessspecifier___________10;

public class Defineaccessspecifier {
	
	private String name1="Rahul";   // global variable
	
	String name2="shiri";// global variable
	
	public String name3="aashish";// global variable
	
	protected String name4="mayuri";// global variable

	public static void main(String[] args) {
		
		// create object for calling non static method
		Defineaccessspecifier RM= new Defineaccessspecifier();
		RM.who1();
		RM.who2();
		RM.who3();
		RM.who4();
		
		
		
		
		
	}
	
	private void who1()
	{
		System.out.println("my name is  "+name1);//printing statement 
	}
	void who2() 
	{
		System.out.println("my name is  "+name2);//printing statement
	}
	public void who3()
	{
	   System.out.println("my name is  "+name3);//printing statement
	}
	protected void who4() {
		System.out.println("my name is  "+name4);//printing statement
	}
	
}
