package Accessspecifier___________10;

public class TesteraccesspecifierR1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// only private specifier will not calling
		AccesspecifierR1 HH1= new AccesspecifierR1();
		HH1.whichclass2();
		HH1.whichclass3();
		HH1.whichclass4();

	}

}
