package Accessspecifier___________10;

public class AccesspecifierR1 {
	
	private String names1="hello iam private class"; // global variable
	
	String names2 ="hello i am default class";  // global variable

	public String names3 ="hello iam public class";  // global variable
	
	protected String names4 ="hello i am protected class"; // global variable
	
	public static void main(String[] args) {
		AccesspecifierR1 HH= new AccesspecifierR1();
		HH.whichclass1();// all access specifier calling in main method of same class
		HH.whichclass2();// all access specifier calling in main method of same class
		HH.whichclass3();// all access specifier calling in main method of same class
		HH.whichclass4();// all access specifier calling in main method of same class
		
		
		
	}
	
	private void whichclass1() {
		
		System.out.println("which class "+names1);
	}
	 void whichclass2() {
		System.out.println("which class "+names2);
	}
	 public void whichclass3 () {
		System.out.println("which class "+names3);
	}
	 protected void whichclass4() {
		System.out.println("which class "+names4);
	}
}
