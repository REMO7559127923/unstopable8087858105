package Accessspecifier___________10;

public class Testaccessspecifier {
	
	
	
	
	
	public static void main(String[] args) {
		// only private specifier will not calling
		Defineaccessspecifier RM1=new Defineaccessspecifier();
		RM1.who2();//only default specifier calling
		RM1.who3();//only protected specifier calling
		RM1.who4();//only public specifier calling
		
		
		
		
	}

}
