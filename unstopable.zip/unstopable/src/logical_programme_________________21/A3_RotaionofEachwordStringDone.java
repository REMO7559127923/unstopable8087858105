package logical_programme_________________21;

public class A3_RotaionofEachwordStringDone {

	public static void main(String[] args) {
		String str1="uvxyz";
		String str2="yzuvx";
	boolean result = (str1.length()==str2.length())&&(str1+str2).contains(str2);
	System.out.println(str1.equals(str2)?" are rotation ":"not rotation");
	boolean resultw= (str1.length()==str2.length()) && (str1+str1).contains(str2);
	System.out.println(resultw?"are rotaion ":"not rotaion");
	}

}
