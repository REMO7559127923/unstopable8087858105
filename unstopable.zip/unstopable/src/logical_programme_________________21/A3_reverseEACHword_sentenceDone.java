package logical_programme_________________21;

public class A3_reverseEACHword_sentenceDone {
	public static void main(String[] args) {
		String str = "im loving with renuka";

		String[] input = str.split(" ");

		StringBuilder sb = new StringBuilder();

		for (String logic : input) {
			sb.append(new StringBuilder(logic).reverse().toString()).append(" ");
		}
		System.out.println("After reverseing each word :   "+sb.toString().trim());
	}
}
