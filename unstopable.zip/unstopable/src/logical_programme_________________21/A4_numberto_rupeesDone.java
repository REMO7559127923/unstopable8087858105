package logical_programme_________________21;

import java.text.NumberFormat;
import java.util.Locale;

public class A4_numberto_rupeesDone {

	public static void main(String[] args) {
		
		
		
		long num=123456789;
		// utilise for that Numberfomat
		
		NumberFormat logic = NumberFormat.getCurrencyInstance(new Locale("en", "IN"));
String rupees = logic.format(num).replace("₹", "Rs.");

System.out.println(" the given number is convert to rupees "+rupees);
		// TODO Auto-generated method stub

	}

}
