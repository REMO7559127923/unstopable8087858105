package logical_programme_________________21;

public class A4_multiplicationWO_operatorDone {

	public static void main(String[] args) {

		
		int a=3;
		int b=5;
		int sum=0;
		
		
		
		for(int i=0;i<b;i++) {
			sum=sum+a;
		}
		
		
		System.out.println(" the given mutilcation is "+sum);
	}

}
