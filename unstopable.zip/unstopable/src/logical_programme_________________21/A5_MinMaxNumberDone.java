package logical_programme_________________21;

public class A5_MinMaxNumberDone {

	public static void main(String[] args) {
		
		int [] number = {1,2,3,4,5,6};
		
		int min=number[0];
		int max=number[0];
		
		for(int logic :number) {
			if(logic>max) {
				max=logic;
			}
			if(logic<min) {
				min=logic;
			}
		}
		
		
System.out.println(" the given number in array maximum is "+max);
System.out.println(" the given number in array minimum is "+min);

	}

}
