package logical_programme_________________21;

import java.util.HashMap;
import java.util.Map;

public class A0_Duplicate_charcter_countDone {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String  str="raaahuluuuuubaaadgjaraaaa";
		Map<Character, Integer> logic =new HashMap<>();
		for(char ch:str.toCharArray()) {
			logic.put(ch, logic.getOrDefault(ch, 0)+1);
		}
		
		
		
		for(char printch:logic.keySet()) {
			if(logic.get(printch)>1) {
				System.out.println(" the given duplicate "+printch+"   :charcter occurance is "+logic.get(printch));
			}
		}

	}

}
