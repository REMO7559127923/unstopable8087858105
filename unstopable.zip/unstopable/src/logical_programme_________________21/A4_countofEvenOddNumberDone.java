package logical_programme_________________21;

public class A4_countofEvenOddNumberDone {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	//	int [] num= {1,1,1,1,1,3,3,3,4,4,4};
		int num=1151615268;
		int even=0;
		int odd=0;
		
		while(num>0) {
			int rem=num%10;
			if(rem%2==0) {
				even++;
			}
			else {
				odd++;
			}
			num=num/10;
		}
		System.out.println("the given even count is " + even);
		System.out.println(" the given odd count is " + odd);
	}

}
