package logical_programme_________________21;

import java.util.HashMap;
import java.util.Map;

public class A0_Number_OcuranceDone {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int [] number= {1,1,1,22,2,2,2,2,2,2,2,5,5,5,5,5,5};
        Map<Integer, Integer> logic =new HashMap<>();
        
        for(int num:number) {
        	logic.put(num, logic.getOrDefault(num, 0)+1);
        }
        
        
        
        System.out.println(" the given number is occurance "+logic);
	}

}
