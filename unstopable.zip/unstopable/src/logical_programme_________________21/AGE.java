package logical_programme_________________21;

public class AGE {
public static void main(String[] args) throws Exception {
	
	
	int age=19;
	
	if(age<18) {
	throw new Exception("user is not in age");
	}
	else {
		System.out.println("user register successfully");
	}
	
	
}
}
