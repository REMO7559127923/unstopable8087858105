     package logical_programme_________________21;

public class A6_CapitiliseFirstLetterDone {
	public static void main(String[] args) {
		String str = "applefruit balllether catmeow dogbark";

		String[] input = str.split(" ");

		StringBuilder sb = new StringBuilder();

		for (String logic : input) {
			for (int i = 0; i < logic.length(); i++) {
				if (i == 0 || i == 1 || i == 3) {
					sb.append(Character.toUpperCase(logic.charAt(i)));

				} else {
					sb.append(logic.charAt(i));
				}
			}

			sb.append(" ");
		}
		System.out.println(sb.toString().trim());
	}
}
