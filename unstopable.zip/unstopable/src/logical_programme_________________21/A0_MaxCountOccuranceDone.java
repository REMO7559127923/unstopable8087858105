package logical_programme_________________21;

import java.util.HashMap;
import java.util.Map;

public class A0_MaxCountOccuranceDone {

	public static void main(String[] args) {
		String str = "success";
int maxcount=0;
char maxchar=' ';
	Map<Character,Integer> logic=new HashMap<>();
	for(char ch:str.toCharArray()) {
		logic.put(ch, logic.getOrDefault(ch, 0)+1);
		
		if(logic.get(ch)>maxcount) {
			maxchar=ch;
			maxcount=logic.get(ch);
		}
		
	}
	
	System.out.println("the given charcter :"+maxchar+"  :and count is "+maxcount);
	
	}

}
