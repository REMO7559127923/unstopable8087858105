package logical_programme_________________21;

public class A3_ReversedNumberWithStringReverse {

    public static void main(String[] args) {

        int num = 12321; // Input number
        String numStr = Integer.toString(num); // Convert number to string
        String revStr = ""; // To store the reversed string

        // Reverse the string representation of the number
        for (int i = numStr.length() - 1; i >= 0; i--) {
            revStr += numStr.charAt(i); // Append characters in reverse order
        }

        int revNum = Integer.parseInt(revStr); // Convert reversed string back to integer
        System.out.println("Reversed Number: " + revNum);

        // Check if the number is a palindrome
        if (num == revNum) {
            System.out.println("Palindrome number");
        } else {
            System.out.println("Not a palindrome");
        }
    }
}
