package logical_programme_________________21;

public class A6_NumberCountDone {

	public static void main(String[] args) {

		int[] number = { 1, 2, 4, 5, 6, 7, 8, 9, 0, 8, 7 };

		int count = 0;
		for (int logic : number) {

			while (logic > 0) {
				logic = logic / 10;
				count++;

			}

		}
		System.out.println("the given count is " + count);
	}

}
