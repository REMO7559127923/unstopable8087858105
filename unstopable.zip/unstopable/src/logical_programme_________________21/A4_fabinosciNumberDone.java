package logical_programme_________________21;

public class A4_fabinosciNumberDone {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	int num=12;
	int a=0;
	int b=1;
	for(int i=0;i<=num;i++) {
		System.out.println(" "+a);
		// temp swap
		int temp=a;
		a=b;
		b=b+temp;
		
		
		
	}
		
		
	}

}
