package logical_programme_________________21;

import java.util.Arrays;

public class A5_secondLargestDone {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="i love you renuka ";
		String[] input = str.split(" ");
		
		String longest=input[0];
		String secondlongest=input[0];
		String max=input[input.length-1];
		String smax=input[input.length-2];
		System.out.println(max);
		System.out.println(smax);
		
		for(String logic:input) {
			if(logic.length()>longest.length()) {
			secondlongest=longest;
				longest=logic;
				
			}
			
			if(logic.length()>secondlongest.length() && logic.length()!=longest.length()) {
				secondlongest=logic;
			}
			
		}
		
		
		System.out.println(" the given longest string is "+longest);
		System.out.println(" the gievn secondlongest string is "+secondlongest);
//
	}

}
