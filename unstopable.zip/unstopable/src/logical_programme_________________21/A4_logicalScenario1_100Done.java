package logical_programme_________________21;

public class A4_logicalScenario1_100Done {

	public static void main(String[] args) {
// apply for loop 100 count

		for (int i = 0; i <= 100; i++) {

			StringBuilder sb = new StringBuilder();
			if (i % 2 == 0) {
				sb.append("hello");
			}

			if (i % 7 == 0) {
				if (sb.length() > 0)
					sb.append(" ");
				sb.append("world");
			}

			// print itself
			if (sb.length() == 0) {
				System.out.println(i);
			} else {
				System.out.println(sb.toString());
			}
		}
	}

}
