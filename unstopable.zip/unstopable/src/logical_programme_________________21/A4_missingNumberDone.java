package logical_programme_________________21;

public class A4_missingNumberDone {
	public static void main(String[] args) {
		int[] num = { 1,3,5,9};
		// find the missing number
		int n = num.length + 1;
		int expectedsum = n * n ;// for plain continue tion if suppose evennumber /2 remove n*(n+1);
		// if number is{1,2,3,4,5,6,8} in continue then n*(n+1)/2
		//if number is odd {1,3,5,7,11} then n*n
		int actualsum = 0;

		for (int logic : num) {
			actualsum += logic;
		}
		
		System.out.println(expectedsum-actualsum);
	}

}
