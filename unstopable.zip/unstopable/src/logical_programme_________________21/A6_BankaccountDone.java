package logical_programme_________________21;

public class A6_BankaccountDone {
	
	public static void main(String[] args) {
		double balanced=30000;
		double addmoney=4000;
		if(addmoney>0) {
			balanced+=addmoney;
		}
		double withdraw=9000;
		if(withdraw>0) {
			balanced-=withdraw;
		}
		System.out.println("updated balanced is "+balanced);
	}

}
