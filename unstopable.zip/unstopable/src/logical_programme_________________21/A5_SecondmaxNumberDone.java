package logical_programme_________________21;

public class A5_SecondmaxNumberDone {
	public static void main(String[] args) {
		int [] number1= {1,4,5,6,78,93};
		
		int max1=number1[number1.length-1];
		int smax=number1[number1.length-4];
		System.out.println(max1);
		System.out.println(smax);
	
//aproch 2nd
		int maximum=number1[0];
		int smaximum=number1[1];
		
		for(int logic:number1) {
			
			if(logic>maximum) {
				smaximum=maximum;
				maximum=logic;
			}
			if(logic>smaximum && logic!=maximum) {
				smaximum=logic;
			}
			
			
		}
		System.out.println("maximum number is in given string is "+maximum);
		System.out.println("maximum number is in given string is "+smaximum);
		
	}

}
