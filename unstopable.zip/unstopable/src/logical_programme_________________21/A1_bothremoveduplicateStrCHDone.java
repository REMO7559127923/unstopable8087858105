package logical_programme_________________21;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public class A1_bothremoveduplicateStrCHDone {
	public static void main(String[] args) {
		String str = "java java java kya hai drama";
		String input = str.replace("", " ");
		StringBuilder sb = new StringBuilder();
		Set<Character> unique = new HashSet<>();

		for (Character logic : input.toCharArray()) {
			if (unique.add(logic)) {
				sb.append(logic);
			}

		}

		System.out.println(sb.toString().trim());
		
		
		String[] input2 = str.split("\\s+"); // Split the string into words
        LinkedHashSet<String> unique2 = new LinkedHashSet<>();
        for (String sr : input2) {
        	unique2.add(sr); // Add returns false if word is already in the set
        }
        String wordResult = String.join(" ", unique2); // Join the words back into a single string

        // Print Results
        System.out.println("Original String: " + str);
        System.out.println("Word-Level Deduplication: " + wordResult);
	}
}
