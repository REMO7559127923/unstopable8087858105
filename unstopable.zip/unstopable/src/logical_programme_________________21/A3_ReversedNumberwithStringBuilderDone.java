package logical_programme_________________21;

public class A3_ReversedNumberwithStringBuilderDone {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int num=1234;
		StringBuilder sb=new StringBuilder();
		sb.append(num).reverse();
		System.out.println(" the given number after reversed is "+sb);
		
		

	}

}
