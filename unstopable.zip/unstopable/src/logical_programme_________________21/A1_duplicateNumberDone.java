package logical_programme_________________21;

import java.util.HashSet;
import java.util.Set;

public class A1_duplicateNumberDone {
	public static void main(String[] args) {
		
	
	
	int[] number= {1,2,3,4,5,6,7,1,2,3,4,56,7};
	
	
	Set<Integer> unique =new HashSet<>();
	Set<Integer>duplicate=new HashSet<>();
	for(int logic:number) {
		if(!unique.add(logic)) {
			duplicate.add(logic);
		}
	}
System.out.println(" the given duplicate number is "+duplicate);
}}
