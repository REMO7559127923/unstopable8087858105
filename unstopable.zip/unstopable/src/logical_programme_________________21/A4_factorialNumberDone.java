package logical_programme_________________21;

public class A4_factorialNumberDone {

	public static void main(String[] args) {
		
		int num=6;
		int fact=1;
		for(int i=num;i>0;i--) {
			fact=fact*i;
			
			
		}
		System.out.println(" the given number "+num+"   factorial is "+fact);
	}

}
