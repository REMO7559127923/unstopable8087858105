package logical_programme_________________21;

public class A4_tableOutputDone {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int num=11;
		
		if(num%2==0 && num%7==0) {
			System.out.println(" enter the number ");
			
		}
		else if(num%2==0) {
			System.out.println("Hello");
		}
		else if(num%7==0) {
			System.out.println("world");
		}
		else {
			System.out.println(" the given number is not in table");
		}
	}

}
