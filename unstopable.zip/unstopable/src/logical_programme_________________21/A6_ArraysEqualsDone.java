package logical_programme_________________21;

import java.io.ObjectInputFilter.Status;
import java.util.Arrays;

public class A6_ArraysEqualsDone {

	public static void main(String[] args) {

		int[] ar1 = { 1, 2, 3, 4 };
		int[] ar2 = { 1, 2, 3 };

		boolean status = true;

//		if (ar1.length == ar2.length) {// pahele array ki length check karni hai

		if (ar1.length == ar2.length) {
			for (int i = 0; i <= ar1.length; i++) {
				if (ar1[i] != ar2[i]) {
					status = false;
					break;

				}
			}
		}

		else {

			status = false;
		}

		System.out.println("result ");
		if (status = true) {
			System.out.println("Arrays is Equals ");
		} else {
			System.out.println("Arrays is Not Equals");
		}
	}

}
