package logical_programme_________________21;

import java.util.HashMap;
import java.util.Map;

import java.util.HashMap;
import java.util.Map;

public class A0_String_DuplicateCountDone {
    public static void main(String[] args) {
        String str = "java java kya he drmaa";
        String[] input = str.split(" ");
        
        Map<String, Integer> logic = new HashMap<>();
        
        // Counting occurrences of each word
        for (String sr : input) {
            logic.put(sr, logic.getOrDefault(sr, 0) + 1);
        }
        System.out.println(logic);
        
        // Printing duplicate counts using keySet
        for (String printsr : logic.keySet()) {
            if (logic.get(printsr) > 1) {
                System.out.println("The given string duplicate count for '" + printsr + "' is: " + logic.get(printsr));
            }
        }
    }
}
