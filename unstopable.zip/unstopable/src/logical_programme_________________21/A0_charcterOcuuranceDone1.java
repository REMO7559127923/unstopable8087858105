package logical_programme_________________21;

import java.util.HashMap;
import java.util.Map;

public class A0_charcterOcuuranceDone1 {
	public static void main(String[] args) {
		
	
String str="Rahul Badgujar";
String input=str.replace(" ","");



Map<Character, Integer > logic=new HashMap<>();
for(Character ch:input.toCharArray()) {
	
	//ch=Character.toLowerCase(ch);
	logic.put(ch, logic.getOrDefault(ch, 0)+1);
	
	
	
}
System.out.println("the given charcter occurance  in string "+logic);
	for(Character printchar:logic.keySet()) {
	if(logic.get(printchar)>1) {
		System.out.println(" the given character "+printchar+"     duplicate count is "+logic.get(printchar)       );
		
	}
	}
	
	
	}
}