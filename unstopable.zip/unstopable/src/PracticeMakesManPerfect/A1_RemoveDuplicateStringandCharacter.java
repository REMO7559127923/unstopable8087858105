package PracticeMakesManPerfect;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public class A1_RemoveDuplicateStringandCharacter {
	
	public static void main(String[] args) {
		String str="Zebrra Crossing Zebrra Crossing i";
		int number=1222337878;
		
		Set<Character> unique=new HashSet<>();
		
		StringBuilder sb=new StringBuilder();
		for(Character logic:str.toCharArray()) {
			if(unique.add(logic)) {
				sb.append(logic);
			}
		}
		System.out.println("After removing duplicate character string is  :"+sb.toString());
		// for string 
		LinkedHashSet<String> unique2=new LinkedHashSet<>();
		for(String logic2:str.split(" ")) {
			unique2.add(logic2);
		}
		
		System.out.println("After removing duplicate string is    :"+unique2);
		// for number
	//sabse pahele number ko String  me cover karna padenga 
		
      String input=String.valueOf(number);
      Set<Character> unique3=new LinkedHashSet<>();
      StringBuilder nb=new StringBuilder();
      
      for(char logic3:input.toCharArray()) {
    	  if(unique3.add(logic3)) {
    	 nb.append(logic3);
    	  }
      }
      int modifiednumber=Integer.parseInt(nb.toString());
      System.out.println("after removing duplicate number "+modifiednumber);
	}

}
