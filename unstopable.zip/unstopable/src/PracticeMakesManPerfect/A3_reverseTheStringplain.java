package PracticeMakesManPerfect;

public class A3_reverseTheStringplain {
public static void main(String[] args) {
	String str="RAAHUL BADGUJAR RAJUGDAB LUHAAR";
	String input=str.replaceAll(" ", "");
	String rev="";
	for(int i=input.length()-1;i>=0;i--) {
		char txt=input.charAt(i);
		rev=rev+txt;
	}
	System.out.println(rev);
	if(input.equals(rev)) {
		System.out.println("paildrome");
	}
	else {
		System.out.println("non paildrome");
	}
}
}
