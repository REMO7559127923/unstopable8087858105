package PracticeMakesManPerfect;

public class A3_reversetheNumberlogical {
	public static void main(String[] args) {
		int num = 1221;
		int originalnum=num;
		int rev = 0;

		while (num > 0) {
			rev = rev *10 + num % 10;
			num = num / 10;

		}
		System.out.println(rev);
		if (originalnum == rev) {
			System.out.println("paildrome");
		} else {
			System.out.println("non paildrome");
		}
	}
}
