package PracticeMakesManPerfect;

import java.util.HashMap;
import java.util.Map;

public class A0_NumberOccurancewithDuplicate {
	public static void main(String[] args) {
		int []number= {1,3,4,5,7,8,4,5,67,83,3};
		Map<Integer, Integer> logic=new HashMap<>();
		for(int num:number) {
			logic.put(num, logic.getOrDefault(num, 0)+1);
		}
		System.out.println("number occurance is : "+logic);
		for(int printnum:logic.keySet()) {
			if(logic.get(printnum)>1) {
				System.out.println("duplicate number :"+printnum+" count :"+logic.get(printnum));
			}
		}
		
		
		
		
	}

}
