package PracticeMakesManPerfect;

public class A3_reversetheNumberwithString {
	public static void main(String[] args) {
		int num=1221;
		String str=Integer.toString(num);
		String rev="";
		
		for(int i=str.length()-1;i>=0;i--) {
			char txt=str.charAt(i);
			rev=rev+txt;
		}
		int revnum=Integer.parseInt(rev);
		System.out.println(revnum);
		
		if(num==revnum) {
			System.out.println("paildrome number");
		}
		else {
			System.out.println("non paildrome number");
		}
	}

}
