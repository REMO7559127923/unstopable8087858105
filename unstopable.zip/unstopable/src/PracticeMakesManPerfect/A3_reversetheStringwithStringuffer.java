package PracticeMakesManPerfect;

public class A3_reversetheStringwithStringuffer {
public static void main(String[] args) {
	String str="mom";
	StringBuffer sb=new StringBuffer(str);
	String rev=sb.reverse().toString();
	System.out.println(rev);
	System.out.println(str.equals(rev)?"paildrome":"nonpaildrome");
}
}
