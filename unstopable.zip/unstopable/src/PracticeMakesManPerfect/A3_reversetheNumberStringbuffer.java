package PracticeMakesManPerfect;

public class A3_reversetheNumberStringbuffer {
	public static void main(String[] args) {
		int num=1221;
		StringBuffer sb=new StringBuffer(String.valueOf(num));
		String result=sb.reverse().toString();
		System.out.println(result);
		if(String.valueOf(num).equals(result)) {
			System.out.println("paildrome");
		}
		else {
			System.out.println("non paildrome");
		}
	}

}
