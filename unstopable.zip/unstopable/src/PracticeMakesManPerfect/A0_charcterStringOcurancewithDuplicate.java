package PracticeMakesManPerfect;

import java.util.HashMap;
import java.util.Map;

public class A0_charcterStringOcurancewithDuplicate {

    public static void main(String[] args) {
        // TODO Auto-generated method stub

        String str = "RAAHUL BADGUJAR RAAHUL BADGUJAR yrm";
        String[] input2 = str.split(" ");
        String input=str.replace(" ","");
        
        Map<Character, Integer> logic1 = new HashMap<>();

        for (char ch : input.toCharArray()) {
            logic1.put(ch, logic1.getOrDefault(ch, 0) + 1);
        }
        System.out.println("The given character occurrence is: " + logic1);

        // For duplicate count of character
        for (char printcr : logic1.keySet()) {
            if (logic1.get(printcr) > 1) {
                System.out.println("Duplicate character: '" + printcr + "' appears " + logic1.get(printcr) + " times.");
            }
        }

        // Word occurrence logic (moved inside main)
        Map<String, Integer> logic2 = new HashMap<>();
        for (String sr : input2) {
            logic2.put(sr, logic2.getOrDefault(sr, 0) + 1);
        }
        System.out.println("The given string occurrence count is: " + logic2);

        // For duplicate count of string
        for (String printsr : logic2.keySet()) {
            if (logic2.get(printsr) > 1) {
                System.out.println("Duplicate word: '" + printsr + "' appears " + logic2.get(printsr) + " times.");
            }
        }
        
        //...............//////
    }
}
