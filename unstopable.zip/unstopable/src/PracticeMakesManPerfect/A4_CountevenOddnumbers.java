package PracticeMakesManPerfect;

public class A4_CountevenOddnumbers {
	public static void main(String[] args) {
//		int []num= {1,2,3,4,5,6,7,8,9};
//		int evencount=num[0];
//		int oddcount=num[0];
		
		
		int num=123456789;
		int evencount=0;
		int oddcount=0;
		
	while(num>0) {
		int rem=num%10;
		if(rem%2==0) {
			evencount++;
		}
		else {
			oddcount++;
		}
		num=num/10;
	}
	
		
		
		
//		for(int logic:num) {
//			if(logic%2==0) {
//				evencount++;
//			}
//			else {
//				oddcount++;
//			}
//		}
		System.out.println(evencount);
		System.out.println(oddcount);
	}

}
