package PracticeMakesManPerfect;

public class A7_StringProcessing {
	public static void main(String[] args) {
		String[] str = {"apple","banana","grapes","watermelon","oranges","kiwi"};

		for (String logic : str) {
			StringBuilder sb = new StringBuilder();
			if (logic.length() % 2 == 0) {
				sb.append(" even ");
			} else {
				sb.append(" odd ");
			}
			if (logic.matches(".*[AEIOUaeiou].*")) {
				sb.append(" vovels ");
			}
			if (logic.contains("s")) {
				sb.append("  has contains s ");
			}

			sb.append(logic);
			System.out.println(logic+"  the fruit"+sb.toString());

		}

	}

}
