package PracticeMakesManPerfect;

public class A4_numberProgram {

	public static void main(String[] args) {
		
		int num=123456789;
		
		// given number count
		int count=0;
		while(num>0) {
			int temp=num%10;
			count++;
			num=num/10;
		}
		
		System.out.println(count);
		
		// for sum of digit
		int num2=12456789;
		int sum=0;
		while(num2>0) {
			sum+=num2%10;
			num2=num2/10;
			
		}
	System.out.println(sum);
    
	}

}
