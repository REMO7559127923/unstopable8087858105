package PracticeMakesManPerfect;

public class A4_print100_multiply2_and_multiply7 {

	public static void main(String[] args) {

		for (int i = 0; i <= 100; i++) {
			StringBuilder sb = new StringBuilder();
			if (i % 2 == 0) {
				sb.append("Hello");
			} 
			if (i % 7 == 0) {
				if (sb.length()>0)
					sb.append(" ");
				sb.append("world");

			}
			if(sb.length()==0) {
				System.out.println(i);
			}
			else {
				System.out.println(sb.toString());
			}
		}
	}

}
