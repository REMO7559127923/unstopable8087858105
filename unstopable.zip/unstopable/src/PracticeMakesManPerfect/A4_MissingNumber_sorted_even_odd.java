package PracticeMakesManPerfect;

public class A4_MissingNumber_sorted_even_odd {

	
	public static void main(String[] args) {
		int []num= {1,2,3,4,5,6,7,9};
		
		int n=num.length+1;
		int expecednum=n*(n+1)/2;
		//for even expected =n*(n+1);
		//for odd expected =n*n;
		int actualsum=0;
		
		for(int logic :num) {
			actualsum+=logic;
		}
		System.out.println(expecednum-actualsum);
	}
}
