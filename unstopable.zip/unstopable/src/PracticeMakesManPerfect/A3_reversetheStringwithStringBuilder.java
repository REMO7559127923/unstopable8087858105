package PracticeMakesManPerfect;

public class A3_reversetheStringwithStringBuilder {
	public static void main(String[] args) {
		String str="raahul badgujarrajugdab luhaar";
	String input=str.replaceAll(" ", "");
		
		StringBuilder sb=new StringBuilder();
		String rev=sb.append(input).reverse().toString();
         System.out.println(rev);
         System.out.println(input.equals(rev)?"paildrome":"not paildrome");
				
	}

}
