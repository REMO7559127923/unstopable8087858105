package PracticeMakesManPerfect;

public class A3_reversetheNumberwithStringwithStringBuilder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=1221;
	
		StringBuilder sb=new StringBuilder();
	String rev=	sb.append(num).reverse().toString();
	System.out.println(rev);
	if(String.valueOf(num).equals(rev)) {
		System.out.println("paildrome");
	}
	else {
		System.out.println("non paildrome");
	}
	}

}
