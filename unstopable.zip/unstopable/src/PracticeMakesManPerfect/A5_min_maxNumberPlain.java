package PracticeMakesManPerfect;

public class A5_min_maxNumberPlain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=123456789;
		int min=9;
		int max=0;
	//	int smax=1; for second max;
		
		while(num>0) {
			int digit=num%10;
			if(digit>max) {
				
				max=digit;
			}
			if(digit<min) {
				min=digit;
			}
			num=num/10;
		}
System.out.println(max);
System.out.println(min);
	}

}
