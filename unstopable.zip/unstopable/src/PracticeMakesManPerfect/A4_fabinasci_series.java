package PracticeMakesManPerfect;

public class A4_fabinasci_series {
	
	public static void main(String[] args) {
		int num=12;
		int a=0;
		int b=1;
		
		System.out.println("given fabinosci series is :");
		for(int i=0;i<num;i++) {
			System.out.println(" "+a);
			
			int temp=a;
			a=b;
					b=b+temp;
		}
		
		
	}

}
