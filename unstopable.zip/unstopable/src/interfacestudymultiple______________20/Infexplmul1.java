package interfacestudymultiple______________20;

public interface Infexplmul1 {
	
	void name1();
	void name2();
	
	default void city() {
		
		
		System.out.println("the city is pune");
		
	}
	
	static void classes () 
	{
		System.out.println("the class branch is katraj");
		
	}
	
	

}
