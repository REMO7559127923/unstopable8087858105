package interfacestudymultiple______________20;

public class Infcallexplmul implements Infexplmul1,Infexplmul2{
	
	
	
	
	
	public static void main(String[] args) {
		Infcallexplmul RM=new Infcallexplmul();
		RM.name1();
		RM.name2();
		RM.name3();
		RM.name4();
		RM.city();
		
		Infexplmul1.classes();
		Infexplmul2.classes();
		
		
		
	}
	
	
	
	
	

	@Override
	public void city() {
		// TODO Auto-generated method stub
		Infexplmul2.super.city();
		Infexplmul1.super.city();
	}

	@Override
	public void name3() {
		// TODO Auto-generated method stub
		System.out.println(" my name is mayuri");
	}

	@Override
	public void name4() {
		// TODO Auto-generated method stub
		System.out.println("my name is ashish");
	}

	@Override
	public void name1() {
		// TODO Auto-generated method stub
		System.out.println("my name is rahul");
	}

	@Override
	public void name2() {
		// TODO Auto-generated method stub
		System.out.println("my name is shiri");
	}

	
	
	
}
