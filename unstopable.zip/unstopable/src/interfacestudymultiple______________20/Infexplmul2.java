package interfacestudymultiple______________20;

public interface Infexplmul2 {
	
	void name3();
	void name4();
	
	default void city()
	{
		
		System.out.println("the city is  mumbai");
		
	}
	static void classes()
	{
		System.out.println("the class branch is bandra");
		
	}

}
