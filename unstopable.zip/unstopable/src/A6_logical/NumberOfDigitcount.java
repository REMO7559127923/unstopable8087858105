package A6_logical;

public class NumberOfDigitcount {
	public static void main(String[] args) {
	
//		int number= 123456789;
//		
//		
//		int count=0;
//
//		while(number>0)
//		{
//			number=number/10;
//			count++;
//		}
//
//System.out.println(" the given number digit is"+ count);
		
		//if input is in array 
		int []number= {1,2,3,4,5,6,7};
		int count=0;
		for(int num:number) {
			
			while(num>0) {
				num=num/10;
				count++;
				
			}
		}

		System.out.println(" the given number digit is    "+ count);



}}
