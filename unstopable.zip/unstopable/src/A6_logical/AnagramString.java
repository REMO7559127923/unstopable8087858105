package A6_logical;

import java.util.Arrays;

public class AnagramString {
	public static void main(String[] args) {
		String st1 = "army";
		String st2 = "mary";

		char[] arr1 = st1.toCharArray();
		char[] arr2 = st2.toCharArray();
		
		
		Arrays.sort(arr1);
		Arrays.sort(arr2);
		
		System.out.println(Arrays.equals(arr1, arr2)?"Anagram":"not Anagram");

	}

}
