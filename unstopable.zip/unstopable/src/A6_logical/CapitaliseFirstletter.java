     package A6_logical;

public class CapitaliseFirstletter {
public static void main(String[] args) {
	String str="apple ball cat";

String[] input=str.split(" ");

StringBuilder result=new StringBuilder();


for(String logic:input) {
	result.append(Character.toUpperCase(logic.charAt(0)));
	result.append(logic.substring(1));
	result.append(" ");
}

System.out.println("the given string convert first letter with capital "+result);

}}
