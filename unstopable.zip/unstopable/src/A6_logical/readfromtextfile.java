package A6_logical;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;


public class readfromtextfile {
public static void main(String[] args) throws IOException {
	
	File fis=new File("C:\\\\Users\\\\Renuka\\\\OneDrive\\\\Desktop\\\\seleniumtest.txt");
	Scanner sc=new Scanner(fis);
	
	
	
	
	
	
	
	sc.useDelimiter("\\Z");
	
System.out.println(sc.next());// call the sc.next=
	
}
}
