package A6_logical;

public class Bank_account {
	public static void main(String[] args) {
		double balance=2000;
		// for add money 
		double addcash=1000;
		if(addcash>0) {
			balance+=addcash;
			System.out.println("updated balance "+balance);
		}
		
		else {
			System.out.println("invalid deposite ammount");
		}
		// for withdraw money
		
		double withdraw=1500;
		
		if(withdraw>0) {
			balance-=withdraw;
			System.out.println("updated balnce after withdraw amount"+withdraw);
		}
		
		
		
		
		
		
		
	}

}
