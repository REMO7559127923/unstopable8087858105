package A6_logical;

import java.util.Arrays;

public class ArraysEquals {
	public static void main(String[] args) {
		int a[] = { 1, 2, 3 };
		int b[] = { 1, 2, 3 };

//		boolean stats=Arrays.equals(a, b);
//		
//		if(stats==true) {
//			System.out.println("array is equals");
//		}
//		else {
//			System.out.println("array is not equal");
//		}
//		

		boolean status = true;
		if (a.length == b.length) {

			for (int i = 0; i < a.length; i++) {

				if (a[i] != b[i]) {
					status = false;
					break;
				}
			}

		}

		else {
			status = true;
		}
// result
		if (status == true) {
			System.out.println("Arrays is equal");
		} else {
			System.out.println("Arrays is not equal");
		}
	}

}
