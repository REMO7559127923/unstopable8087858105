package A6_logical;

public class RemovespaceString {
public static void main(String[] args) {
	String str="rahhul renuka badgujar";
	String input=str.replaceAll("\\s", "");
	System.out.println("the given string after removing space "+input);
}
}
