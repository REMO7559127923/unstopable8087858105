package pattern_________19;

public class PatternStudy {

	public static void main(String[] args) {
		// number pattern
		int n1 = 5;
		for (int i = 1; i <= n1; i++) { // Initialization
			for (int j = 1; j <= i; j++) {
				System.out.print("1");// conditions
			}
			System.out.println();// updation
		}

		System.out.println("=============================1");

		int n2 = 5;
		for (int i = 1, p = 1; i <= n2; i++, p++) { // Initialization
			for (int j = 1; j <= i; j++) {
				System.out.print(p + "");// conditions
			}
			System.out.println();// updation
		}
		System.out.println("=================================2");
		int n3 = 5;
		for (int i = 1, p = 5; i <= n3; i++, p--) {
			for (int j = 1; j <= i; j++) {
				System.out.print(p + "");
			}
			System.out.println();
		}
		System.out.println("=================================3");

		int n4 = 5;
		for (int i = 1, p = 0; i <= n4; i++, p += 2) {
			for (int j = 1; j <= i; j++) {
				System.out.print(p + "");
			}
			System.out.println();
		}
		System.out.println("=================================4");

		int n5 = 5;
		for (int i = 1, p = 0; i <= n5; i++, p += 2) {
			for (int j = 1; j <= i; j++) {
				if (i % 2 == 0) {
					System.out.print("2");
				} else
					System.out.print("1");
			}
			System.out.println();
		}
		System.out.println("=================================5");

	}

}
