package pattern_________19;

public class Pattern {
      public static void main(String[] args) {
		
    	  for(int i=1;i<=10;i++)// x-- line increment
    	  {
    	  System.out.print("*");
    	  }
    	  for(int i=1;i<=10;i++)// y-- line increment
    	  {
    	  System.out.println("*");
    	  }
    	  
    	  System.out.println("=============================1");
    	  for(int i=1;i<=5;i++)
    	  {
    	  //inner for loop--> for columns-->1--->5
    	  for(int j=1;j<=8;j++)
    	  {
    	  System.out.print("*  ");
    	  }
    	  System.out.println();
    	  }
    	  System.out.println("==================================2");
    	  int star=1;// starting point
    	//outer for loop
    	for(int i=1;i<=5;i++)// y-- line increment
    	{
    	for(int j=1;j<=star;j++)//star=1
    	{
    	System.out.print("*");
    	}
    	star++;
    	System.out.println();
    	}
    	
    	System.out.println("=============================================3");
    	  
    	int star3=10;
    	//rows-->outer for loop-->1-->5
    	for(int i=1;i<=5;i++)
    	{
    	//columns-->inner for loop-->5-->1
    	for(int j=1;j<=star3;j++)
    	{
    	System.out.print("*");
    	}
    	star--;
    	System.out.println();
    	}
    	System.out.println("==========================================4");
    	int star1=10;
    	int space=1;
    	//outer for loop--> rows-->1-->5
    	for(int i=1;i<=8;i++)//-- x line
    	{
    	//for loop for space
    	for(int j=1;j<=space;j++)
    	{
    	System.out.print(" ");
    	}
    	// for loop for star
    	for(int j=1;j<=star1;j++)
    	{
    	System.out.print("*");
    	}
    	System.out.println();
    	star--;
    	space++;
    	}
    	  System.out.println("===========================================5");
    	  int star4=1;
    	  int space3=4;
    	  //outer for loop--> rows
    	  for(int i=1;i<=5;i++)
    	  {
    	  //1st we need space
    	  for(int j=1;j<=space3;j++)
    	  {
    	  System.out.print(" ");
    	  }
    	  //2nd we need star
    	  for(int j=1;j<=star4;j++)
    	  {
    	  System.out.print("*");
    	  }
    	  System.out.println();
    	  space--;
    	  star++;
    	  }
    	  
    	  
    	  
	}
}
