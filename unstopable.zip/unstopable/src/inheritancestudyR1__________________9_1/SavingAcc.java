package inheritancestudyR1__________________9_1;

public class SavingAcc extends Acccount {
	public void hdfcsavingAcc () 
	{// child class1 extend --- superclass
		System.out.println("welcome to saving account");
		
	}

}
