package inheritancestudyR1__________________9_1;

public class CurrentAcc extends SavingAcc{

	public void hdfcCurrentAcC() {
		//child class2 extend child class 1
		System.out.println("welcome to current account");
	}
}
