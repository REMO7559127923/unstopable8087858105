package inheritancestudyR1__________________9_1;

public class LoanAcc extends Acccount{

	
		public void  loanAccount()
		{
			System.out.println("welcome loan account");
		}

	

}
