package inheritancestudyR1__________________9_1;

public class HierarichicalTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Acccount ACC=new Acccount();
		ACC.hdfc();
		
		System.out.println("=============================");
		
		SavingAcc SAV=new SavingAcc();
		ACC.hdfc();// super class
		SAV.hdfcsavingAcc();// child class1
		
		System.out.println("=============================");
		
		LoanAcc LOAN=new LoanAcc();
		LOAN.hdfc();// super class
		LOAN.loanAccount();// child class 2
		
		

	}

}
