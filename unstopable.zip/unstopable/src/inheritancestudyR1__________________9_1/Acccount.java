package inheritancestudyR1__________________9_1;

public class Acccount {
// super class
	public void hdfc() {
		
		System.out.println("welcome to hdfc bank");
	}
}
