package inheritancestudyR1__________________9_1;

public class SingleTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Acccount ACC= new Acccount();
		ACC.hdfc();
		
		System.out.println("================================");
		
	    SavingAcc SAV=new SavingAcc();
	    SAV.hdfc();
	    SAV.hdfcsavingAcc();
	    System.out.println("================================");
	
	}

}
