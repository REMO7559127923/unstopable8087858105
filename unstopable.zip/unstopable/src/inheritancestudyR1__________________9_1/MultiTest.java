package inheritancestudyR1__________________9_1;

public class MultiTest {
	public static void main(String[] args) {
		
		Acccount ACC1= new Acccount();
		ACC1.hdfc();
		
		System.out.println("================================");
		
		SavingAcc SAV1=new SavingAcc();
		SAV1.hdfc();
		SAV1.hdfcsavingAcc();
		
		System.out.println("==================================");
		
		CurrentAcc CC1=new CurrentAcc();
		CC1.hdfc();
		CC1.hdfcsavingAcc();
		CC1.hdfcCurrentAcC();
		
		System.out.println("==================================");
		
	
		
		
	}
	

}
