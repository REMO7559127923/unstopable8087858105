package conditionalstatement______________7;

public class Elseifuse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int money=10;
		
		if(money>=1000) {
			
			System.out.println("dinner party");
			
		}
		
		else if(money>=800) {
			
			System.out.println("pool party");
			
		}
		else if(money>=500) {
			
			
			System.out.println("dessert party");
		}
		else if(money>100) {
			
			
			System.out.println("wadapav party");
		}
		
		else {
			
			System.out.println(""
					+ " आशीष  हांडे ,मनोज सूर्यवंशी no money ghari basa आणि राहुल सोबत   भेळ खा ");
		}
		
		
		
	}

}
