package conditionalstatement______________7;

public class NestedifR1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		String username ="Renuka";
		String passward="R@hul143";
		
		
		if(username=="Renuka") 
		{// opening
			System.out.println("username is correct please enter valid passward");
		
        if(passward=="R@hul143")
        {
        	System.out.println("credentional is valid welcome to home page");
        }
        else 
        {
        	System.out.println("invalid passward please enter  correct passward");
        }
        }// closing
        
        else {
        	System.out.println("invalid login credential contact to bank");
        	
        }
	}

}
