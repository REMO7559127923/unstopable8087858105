package conditionalstatement______________7;

public class Ifelseuse {

	public static void main(String[] args) {
		
		int mrp=100;
		
		
		if(mrp>=1000)
		{
			System.out.println("the main price of product "+mrp);
		}
		
		else {
			System.out.println("you will not able to get product");
		}
		
		
		
		
		
		
		
		
		
	
	
	
	
	
	
}	
	
}





