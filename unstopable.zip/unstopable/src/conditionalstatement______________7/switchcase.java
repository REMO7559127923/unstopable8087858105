package conditionalstatement______________7;

public class switchcase {

	public static void main(String[] args) {
		
		int year=2;
	
		switch(year) {
		
		case 1:
			System.out.println("welcome to 1st year");
		break;
		
		case 2:
			System.out.println("welcome to 12nd year");
		break;
		
		case 3:
			System.out.println("welcome to 3rd year");
		break;
		
		case 4:
			System.out.println("welcome to 4th year");
		break;
		
		default:
			System.out.println("please enter the value between 1-4");
		break;	
        }
	}
	
}
