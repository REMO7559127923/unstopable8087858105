package conditionalstatement______________7;

public class SwitchcaseR1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
           int temperature = 20;
           
           switch(temperature) {
           case 40:
        	   System.out.println("summer season");
           break;
           case 26:
        	   System.out.println(" rainy season ");
           break;
           case 20:
        	   System.out.println("winter season");
         break;
         default:
        	 System.out.println("please enter valid temperature");
           break;
           }
           
	}

}