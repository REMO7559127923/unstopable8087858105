package conditionalstatement______________7;

public class IfuseR1 {
	
	public static void main(String[] args) {
		int cashprice=200;
		int mrpprice=300;
		
		if(cashprice==200);
		System.out.println("if bill in cash "+cashprice);
		
		if(mrpprice==300);
		System.out.println("if bill in online "+mrpprice);
	}

}
