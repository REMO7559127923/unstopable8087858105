package conditionalstatement______________7;

public class Ifuse {

	
	public static void main(String[] args) {
		
		// if statement only use for correct answer
		
		int money=100;
		int mrp=500;
		
		if(money==100);
		{
			System.out.println("only note is valid of "+money);
		}
		if(mrp>=500);
		{
			System.out.println("the mrp of product is "+mrp);
		}
	}
	
	
	
}
