package conditionalstatement______________7;

public class ElseifR1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int marks=10;
		
		if(marks>=90){
			System.out.println("rahul pass with distinction");
		}
		
		else if(marks>=75){
			System.out.println("rahul pass with A grade");
		}
		else if(marks>=60) {
			System.out.println("rahul pass with B grade");
		}
		else if (marks>=35) {
			System.out.println("rahul pass with c grade");
		}
		else {
			System.out.println("rahul failed in the exam");
		}
	}

}
