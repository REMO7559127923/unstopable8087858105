package conditionalstatement______________7;

public class Nestedif {
	
	public static void main(String[] args) {
		
		String username="Rahul";
		String passward="R@hul143";
		
		if(username=="Rahul")
		{
			
			System.out.println("user name is correct,please enter passward");
				
		if(passward=="R@hul1433")
		{
			System.out.println("passward is correct,welcome to home page");
		}
		
		else {
			
			System.out.println("please insert valid passward");
		}
		
		}
		else
		{		
			System.out.println("invalid login and passward");
		}
		
			
		
		
		
	}	
	

}
