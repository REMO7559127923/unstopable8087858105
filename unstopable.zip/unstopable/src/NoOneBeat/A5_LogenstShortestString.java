package NoOneBeat;

public class A5_LogenstShortestString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		String str="raahul badgujar i love you renuka";
		
		String[] input=str.split(" ");
		String longest=input[0];
		String shortest=input[0];
		
		
		for(String logic:input) {
			if(logic.length()>longest.length()) {
				longest=logic;
			}
			if(logic.length()<shortest.length()) {
				shortest=logic;
			}
		}

		
		
		System.out.println(longest);
		System.out.println(shortest);
		
		
	}

}
