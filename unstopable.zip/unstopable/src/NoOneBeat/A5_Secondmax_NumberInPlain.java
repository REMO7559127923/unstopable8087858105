package NoOneBeat;

public class A5_Secondmax_NumberInPlain {
	public static void main(String[] args) {

		int num = 617283945;

	
		int max = 0;
        int smax=1;
		while (num > 0) {
			int digit = num % 10;
			if (digit > max) {
				smax=max;
				max = digit;
			}
			if (digit > smax  && digit!=max) {
				smax = digit;
			}

			num = num / 10;

		}
System.out.println(smax);
System.out.println(max);
	}

}
