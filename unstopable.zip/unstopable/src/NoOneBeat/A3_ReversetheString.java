package NoOneBeat;

public class A3_ReversetheString {
	public static void main(String[] args) {
		String Str="Raahul baddab luhaaR";
		
		String input=Str.replaceAll(" ", "").toLowerCase();
//String cleanStr = str.replaceAll(" ", "").toLowerCase();
        
        // Reverse the string
        String rev = "";
        for (int i = input.length() - 1; i >= 0; i--) {
            rev = rev + input.charAt(i);
        }
        System.out.println(rev);
        // Check if original string is equal to the reversed string
        if (input.equals(rev)) {
            System.out.println("Palindrome");
        } else {
            System.out.println("Not Palindrome");
                }
        
             
}
}