package NoOneBeat;

public class A5_StringReverseProcess {

	public static void main(String[] args) {
		String str="Rahul Vasant Badgujar";
		
		String fp=str.substring(0, 5);
		String sp=str.substring(5, 13);
		String tp=str.substring(13);
		
		
		
		String firstsegment=new StringBuilder(fp).reverse().toString();
		String secondsegment=new StringBuilder(sp).reverse().toString();
		String thirdsegment=new StringBuilder(tp).reverse().toString();
		
		String result=firstsegment+secondsegment+thirdsegment;
		System.out.println(result);
	}
	
}
