package NoOneBeat;

public class A2_swapStringwithoutthirdvariable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
