package NoOneBeat;

public class A4_1to100_printlogic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		for(int i=1;i<=100;i++) {
			StringBuilder sb=new StringBuilder();
			if(i%2==0) {
				
				sb.append("Hello");
			}
			
			if(i%7==0) {
				if(sb.length()>0) {
					sb.append(" ");
					
				}
				sb.append("world");
			}
			
			
			//print balanced
			if(sb.length()==0) {
				System.out.println(i);
			}
			else {
				System.out.println(sb.toString().trim());
			}
			
			
			
			
		}
		
		

	}

}
