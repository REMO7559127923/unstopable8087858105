package NoOneBeat;

public class A7_RemoveVowelsDone {
	public static void main(String[] args) {
		String str="raahul badgujar";
		String input=str.replaceAll("[AEIOUaeiou]", "");
		System.out.println("the given modified     "+input);
		
		
		
		
		
		
	}

}
