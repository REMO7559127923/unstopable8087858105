package NoOneBeat;

public class A3_ReversetheStringwithStringBuffer {

	public static void main(String[] args) {
		
		String str="Raahul Badgujar";
		
		StringBuffer sb=new StringBuffer(str);
		StringBuffer rev=sb.reverse();
		
		System.out.println(rev.toString());
		// TODO Auto-generated method stub

	}

}
