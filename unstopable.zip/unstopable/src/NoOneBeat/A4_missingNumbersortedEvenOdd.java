package NoOneBeat;

public class A4_missingNumbersortedEvenOdd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int []num1= {1,2,3,5};
		int []num2= {2,4,6,10};
		int []num3= {1,3,5,9};
		
		int n1=num1.length+1;
		int n2=num2.length+1;
		int n3=num3.length+1;
		
		
		
		int expected1=n1*(n1+1)/2;
		int expected2=n2*(n2+1);
		int expected3=n3*n3;
		
		int actualsum1=0;
		int actualsum2=0;
		int actualsum3=0;
		
		for(int logic1:num1) {
			actualsum1+=logic1;
		}
		System.out.println("missing number for sorted array  :"+(expected1-actualsum1));
		for(int logic2:num2) {
			actualsum2+=logic2;
		}
		System.out.println("missing number for even array  :"+(expected2-actualsum2));
		for(int logic3:num3) {
			actualsum3+=logic3;
		}
		System.out.println("missing number for odd array  :"+(expected3-actualsum3));
		

	}

}
