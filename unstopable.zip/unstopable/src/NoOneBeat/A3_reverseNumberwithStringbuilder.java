package NoOneBeat;

public class A3_reverseNumberwithStringbuilder {

	
	
	public static void main(String[] args) {
		
int num=1234;

StringBuilder sb=new StringBuilder();
String result =sb.append(num).reverse().toString();
System.out.println(result);
if(String.valueOf(num).equals(result))
		{
	System.out.println("paildrome");
		}
else {
	System.out.println("non paildrome");
}
	}
}
