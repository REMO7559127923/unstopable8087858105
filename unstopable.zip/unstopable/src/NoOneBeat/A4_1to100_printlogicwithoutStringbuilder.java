package NoOneBeat;

public class A4_1to100_printlogicwithoutStringbuilder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
for(int i=1;i<=100;i++) {
	String result="";
if(i%2==0) {
	result+="Hello";
}
	
if(i%7==0) {
	if(!result.isEmpty()) {
		result=" ";
	}
	result+="world";
}
	
	//for print itelf
if(result.isEmpty()) {
	System.out.println(i);
}
else {
	System.out.println(result);
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
		
		

	}

}
