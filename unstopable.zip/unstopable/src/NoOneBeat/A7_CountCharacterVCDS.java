package NoOneBeat;

public class A7_CountCharacterVCDS {
	public static void main(String[] args) {
		String str = "Afsdjdi;h;ii;gksaug6328826^&*^$$&UIao12125";
		// count karan ahai to initialise 0 se karte hi

		int vowelscount = 0;
		int constantcount = 0;
		int digitcount = 0;
		int specialcount = 0;

		StringBuilder sb = new StringBuilder();

		for (char logic : str.toCharArray()) {

			if (Character.isLetter(logic)) {
				if ("AEIOUaeiou".indexOf(logic) != -1)
					vowelscount++;
				constantcount++;

			} else if (Character.isDigit(logic)) {
				digitcount++;
			} else {
				specialcount++;
			}
		}

		System.out.println("the given string contains count of vowelscount" + vowelscount);
		System.out.println("the given string contains count of constantcount" + constantcount);
		System.out.println("the given string contains count of digitcount" + digitcount);
		System.out.println("the given string contains count of specialcount      " + specialcount);

	}

}
