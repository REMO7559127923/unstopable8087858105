package NoOneBeat;

public class A4_FabinoscciNumber {
public static void main(String[] args) {
	
	
	int num=5;
	int a=0;
	int b=1;
	System.out.println("fabinosci series for   "+num+" is :");
	
for(int  i=0;i<num;i++){
	System.out.println(" "+a);

int temp=a;
a=b;
b=b+temp;
}

}
}
