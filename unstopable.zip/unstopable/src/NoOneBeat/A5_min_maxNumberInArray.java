package NoOneBeat;

public class A5_min_maxNumberInArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int []num= {1,2,3,4,5,6,7,8,9};
		
		int min=num[0];
		int max=num[0];
		
		
		for(int logic:num) {
			if(logic>max) {
				max=logic;
			}
			if(logic<min) {
				min=logic;
			}
		}
		
		System.out.println(min);
		System.out.println(max);
		
		

	}

}
