package NoOneBeat;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public class A3_Duplicate_removeBothCharcterandString {
	
	public static void main(String[] args) {
		// write a program for remove duplicate -word aya to samaz lo set use karan he
		
		String str="RAAHUL BADGUJAR RAAHUL BADGUJAR rrjrjr";
	//	String input=str.toLowerCase();
		
		
		Set<Character> unique=new HashSet<>();
		
		StringBuilder sb=new StringBuilder();
		for(Character logic:str.toCharArray()) {
			if(unique.add(logic)) {
				sb.append(logic);
			}
		}
		System.out.println("the given string after remove duplicate string  "+sb.toString().trim());
		
		// remove duplicate from string
		LinkedHashSet<String> unique2=new LinkedHashSet<>();
		for(String logic2:str.split(" ")) {
			unique2.add(logic2);
		}
		
		System.out.println("the given string after remove duplicate string"+unique2);
	}
	
}
