package NoOneBeat;

public class A5_StringProcessorconatins {
	public static void main(String[] args) {
		String[] str = {"apple","banana","grapes","watermelon","oranges","kiwi"};
		

		for (String logic : str) {
			StringBuilder sb = new StringBuilder();
			if (logic.length() % 2 == 0) {  
				sb.append(" even ");
			} else {
				sb.append(" odd ");
			}
			if (logic.matches(".*[AEIOUaeiou].*")) {
				sb.append(" vovels ");
			}
			if (logic.contains("s")) {
				sb.append(" contains s ");
			}

			sb.append(logic);
			System.out.println(sb.toString());
		}

	}
}
