package NoOneBeat;

public class A7_findinStringULDS {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		String str="AEIraahulB12345$%^&*(";
		
		StringBuilder Ucase=new StringBuilder();
		StringBuilder Lcase=new StringBuilder();
		int sum=0;
		StringBuilder Special=new StringBuilder();
		
		
		
		for(char logic:str.toCharArray()) {
		if(Character.isUpperCase(logic)) {
			Ucase.append(logic);
			
		}
		else if(Character.isLowerCase(logic)) {
			Lcase.append(logic);
		}
		else if(Character.isDigit(logic)) {
			sum+=Character.getNumericValue(logic);
		}
		else {
			Special.append(logic);
		}
		}
		
		System.out.println("the given string upercase is "+Ucase);
		System.out.println("the given string lowercase is "+Lcase);
		System.out.println("the given string sum is "+sum);
		System.out.println("the given string special charcter is "+Special);
		

	}

}
