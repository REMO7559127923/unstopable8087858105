package NoOneBeat;

public class A3_reverseNumberwithString {
	public static void main(String[] args) {
		int num=1234;
		
		String input=Integer.toString(num);
		
		String rev="";
		
		for(int i=input.length()-1;i>=0;i--) {
			 char txt=input.charAt(i);
			 rev=rev+txt;
		}
		
		int revnum=Integer.parseInt(rev);
	System.out.println("the given number after reverse  "+revnum);
	
	
	if(num==revnum) {
		System.out.println("given number is paildrome");
	}
	else {
		System.out.println("not paildrome");
	}
	}

}
