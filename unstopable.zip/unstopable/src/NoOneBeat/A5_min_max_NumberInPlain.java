package NoOneBeat;

public class A5_min_max_NumberInPlain {
	public static void main(String[] args) {

		int num = 617283945;

		int min = 9;
		int max = 0;

		while (num > 0) {
			int digit = num % 10;
			if (digit > max) {
				max = digit;
			}
			if (digit < min) {
				min = digit;
			}

			num = num / 10;

		}
System.out.println(min);
System.out.println(max);
	}

}
