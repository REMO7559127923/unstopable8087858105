package NoOneBeat;

public class A3_reverseNumberWithStringBuffer {
	public static void main(String[] args) {
		
	
	
	int num=1221;
	StringBuffer sb=new StringBuffer(String.valueOf(num));
	StringBuffer rev=sb.reverse();
	
	System.out.println(String.valueOf(num).equals(rev.toString())?"paildrom":"not paildrome");

}
}