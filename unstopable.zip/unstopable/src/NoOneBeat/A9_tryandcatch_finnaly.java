package NoOneBeat;

public class A9_tryandcatch_finnaly {
	public static void main(String[] args) {
		try {
			int num=10/0;
			System.out.println("print"+num);
		} catch (NullPointerException e) {
			// TODO: handle exception
			System.out.println("exception cought:"+e.getMessage());
		}
		finally {
			System.out.println("excute always");
			
		}
	}

}
