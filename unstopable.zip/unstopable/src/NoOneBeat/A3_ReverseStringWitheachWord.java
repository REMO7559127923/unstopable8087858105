package NoOneBeat;

public class A3_ReverseStringWitheachWord {  
	public static void main(String[] args) {
		
		
		String str="java java kya hai drama";
		
		
		StringBuilder sb=new StringBuilder();
		String result = sb.append(new StringBuilder(str)).reverse().toString();
		System.out.println(result);
	}

}
