package NoOneBeat;

public class A3_ReversetheWithStringbuilder {
	public static void main(String[] args) {
		
		
		
		String str="Raahul Badgujar";
		
		
		StringBuilder sb=new StringBuilder();
	String rev=	sb.append(str).reverse().toString();
	System.out.println(rev);
		
	}

}
