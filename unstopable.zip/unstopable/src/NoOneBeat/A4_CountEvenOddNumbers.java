package NoOneBeat;

public class A4_CountEvenOddNumbers {

	public static void main(String[] args) {
		
		
int number=123456789;


int evencount=0;
int oddcount=0;


while(number>0) {
	int rem=number%10;
	if(rem%2==0) {
		evencount++;
	}
	else {
		oddcount++;
	}
	number=number/10;
}

System.out.println(evencount);
System.out.println(oddcount);

		// TODO Auto-generated method stub

	}

}
