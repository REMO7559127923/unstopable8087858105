package NoOneBeat;

public class A5_LongestSecondlongestString {
	public static void main(String[] args) {
		String str="RAAHUL VASANT BADGUJAR I LOVE YOU RENUKA ";
		
		String [] input=str.split(" ");
		String longest=input[0];
		String slongest=input[0];
		
		for(String logic:input) {
			
			if(logic.length()>longest.length()) {
			    slongest=longest;
			    
				longest=logic;
			}
			if(logic.length()>slongest.length() && logic.length()!=longest.length()) {
				slongest=logic;
			}
			
		}
		
		System.out.println("the given string is  longest"+longest);
		System.out.println("the given string is  slongest"+slongest);
		
		
		
		
	}

}
