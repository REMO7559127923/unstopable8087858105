package NoOneBeat;

public class A7_replacevowelstheirposition {

	public static void main(String[] args) {
		
		String str="raahul badgujar ilove you ";
		
		int position=1;
		
		StringBuilder sb =new StringBuilder();
		for(char logic:str.toCharArray()) {
			if("AEIOUaeiou".indexOf(logic)!=-1) {
				
				sb.append(position);
				
			}
			else {
				sb.append(logic);
			}
		position++;
		}
		
		// TODO Auto-generated method stub
		System.out.println(sb.toString());

	}

}
