package NoOneBeat;

public class A5_SecondHeighstNumberInplain {

	public static void main(String[] args) {
		
		int num=123456789;
		int max=0;
		int smax=-1;
		
		
		
		while(num>0) {
			int digit=num%10;
			if(digit>max) {
				smax=max;
				max=digit;
			}
			if(digit>smax && digit!=max) {
				smax=digit;
			}
			num=num/10;
		}

System.out.println(max);
System.out.println(smax);

	}

}
