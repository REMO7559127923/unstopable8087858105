package A7_vowels;

public class vovelsreplacepositionDone {
	public static void main(String[] args) {
		String str="raahul aeiyo";
		
		
		StringBuilder sb=new StringBuilder();
		int position=1;
		for(char logic:str.toCharArray()) {
			if("AEIOUaeiou".indexOf(logic)!=-1) {
				sb.append(position);
				
			}
			else {
				sb.append(logic);
			}
			position++;
		}
		
		System.out.println("the gievn string is replace vovels with their position   :__>>>"+sb.toString().trim());
	}
	

}
