 package A7_vowels;

public class StringProcessorDone {
	public static void main(String[] args) {
		String str="AB12@*huk#%)";

	StringBuilder uppercase=new StringBuilder();
	StringBuilder lowercase=new StringBuilder();
	StringBuilder special=new StringBuilder();
	int sum=0;
	
	for(char logic:str.toCharArray()) {
		if(Character.isUpperCase(logic)) {
			uppercase.append(logic);
		}
		else if(Character.isLowerCase(logic)) {
			lowercase.append(logic);
		}
		else if(Character.isDigit(logic)) {
			sum+=Character.getNumericValue(logic);
		}
		else {
			special.append(logic);
		}
	}
		
	System.out.println("uppercase of string is "+uppercase);
	System.out.println("lowercase of string is "+lowercase);	

	System.out.println("sum of number  in string is "+sum);	

	System.out.println("Special charcter of string is "+special);	

		
	}

}
