package A7_vowels;

public class Remove_Vowels {
	public static void main(String[] args) {
		String str="Raahul badgujar ilove you renuka";
		
		String input=str.replaceAll("[AEIOUaeiou]", "");
		
		System.out.println("the given string after modified    :"+input);
		
		
	}

}
