      package A7_vowels;

public class findVCDSDone {
	public static void main(String[] args) {
	String str="AbraaahulBadgujoaoaueyud%#$@123459837";	
	int vowels=0;
	int  constant=0;
	int digit=0;
	int special=0;
	
	for(char logic:str.toCharArray()) {
		if(Character.isLetter(logic)) {
			if("AEIOUaeiou".indexOf(logic)!=-1)vowels++;
			else constant++;
		}
		else if (Character.isDigit(logic)) {
			digit++;
		}
		else {
			special++;
			
		}
	
	
	
	
	
	
	}
	
	
	

	System.out.println(" the given vowels count is "+vowels);
	System.out.println(" the given constant count is "+constant);
	System.out.println(" the given digit count is "+digit);
	System.out.println("the given special charcter is "+special);
		
		
	}

}
