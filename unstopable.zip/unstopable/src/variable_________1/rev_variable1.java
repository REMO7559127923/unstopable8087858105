package variable_________1;

public class rev_variable1 {
	
	public static void main(String[] args) {
		long  mobileno;
		mobileno=8624062433l;
		String s="hello";
		System.out.println("write"+s);
		
		
		
		
		System.out.println(mobileno);
		System.out.println("this is my  "+mobileno);
	}

}
