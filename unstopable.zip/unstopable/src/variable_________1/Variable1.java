package variable_________1;

public class Variable1 {
	
	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
 System.out.println("welcome java");
 System.out.println("hello world");
 System.out.println("i am rahul");
	
// variable study -1
	//variable declaration
 int marks;
 marks=10;
 System.out.println(marks);
System.out.println("total"+marks );	
	


System.out.println("my name is rahul");
}

	

}
