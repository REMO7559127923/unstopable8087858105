package acesstestanother______________10_1;

import Accessspecifier___________10.Defineaccessspecifier;

public class Accesstestdemo 
{
public static void main(String[] args) {
	
Defineaccessspecifier RR1= new Defineaccessspecifier();
RR1.who3();//public class through out project
}
	
	
	
}
