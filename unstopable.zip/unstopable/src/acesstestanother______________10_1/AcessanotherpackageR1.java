package acesstestanother______________10_1;

import Accessspecifier___________10.AccesspecifierR1;

public class AcessanotherpackageR1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   AccesspecifierR1 HH2=new AccesspecifierR1();
   HH2.whichclass3();// public class through out  project
   
	}

}
