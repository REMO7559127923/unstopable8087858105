package variablestudytype2____________5;

public class Test121 {
	int y=1000;// non static global variable
	static int x=50;// static global variable
	public static void main(String[] args) {
		
	}
	
}
