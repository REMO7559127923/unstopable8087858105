package variablestudytype2____________5;

public class Globaltest1 {

	
	static int g2=50;// static global variable
	int g1=10;// non static global variable
	
	public static void main(String[] args) {
		
	}
	
	
}

