package variablestudytype2____________5;

public class Revise_Globalvariable {
	// static global variable                                                  // non static variable
	static int i=7;                                                               int m=9;
	static float j=6.2f;                                                          float n=6.5f;
	static long k=8624062433l;                                                    long o=7711998484l;
	static boolean l=true;                                                        boolean p=false;
	static String names1="rahul badgujar";                                        String names2="renuka badgujar";
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		                                                           //create object
                                                                Revise_Globalvariable RR= new Revise_Globalvariable();
		
		System.out.println("my lucky number "+i);                System.out.println("my lucky number is "+RR.m); 
		System.out.println("my height is "+j);                   System.out.println("my height is "+RR.n);
		System.out.println("my mobile number is "+k);            System.out.println("my mobile number is "+RR.o);
		System.out.println("all information is "+l);             System.out.println("all information is "+RR.p);
		System.out.println("my name is "+names1);                System.out.println("my name is "+RR.names2);
		
		
		

		//math operation
		int add=100+i;                                                  int sub=500-RR.m;
		System.out.println("the add value "+add);                      System.out.println(" the subtraction value is "+sub);
		
		long add2=10+k;                                                 long add3=20+RR.o;
		System.out.println("the add2 value "+add2);                  System.out.println(" the add3 value "+add3);
		
		
		// another class math operation
	int add4=10+Globaltest1.g2;                                        Globaltest1 RRR =new Globaltest1();
                                                                            int add5=10+RRR.g1;
	}

}
