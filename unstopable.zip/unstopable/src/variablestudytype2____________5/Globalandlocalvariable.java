package variablestudytype2____________5;



public class Globalandlocalvariable 

{
	//===============================global variable=================================//
    static  int a=7;                                            int s=8;       
    static float b=6.5f;                                       float t=5.8f;
    static char  c='M';                                       char q='F';
    static String name1="RAHUL";                             String name2="RENUKA";
    static long d=86240062433l;                               long u=7775946977l;
    static boolean e=true;                                   boolean v=false;
    
    //================================================================================//
    public static void main(String[] args) {
	// static method calling from same class          // non static method calling from same class
    	                                              // create object
    	                                              
                                                    Globalandlocalvariable RR=new Globalandlocalvariable();
    System.out.println("my lucky number is "+a);	
                                                           System.out.println("my lucky number is "+RR.s); 
    System.out.println("my height is "+b);              System.out.println("my height is "+RR.t);
    System.out.println("my gender is "+c);              System.out.println("my gender is "+RR.q);
    System.out.println("my name is "+name1);            System.out.println("my name is "+RR.name2);
    System.out.println("my mobile number is "+d);       System.out.println("my mobile number is "+RR.u);
    System.out.println(" all information is "+e);       System.out.println("all information is "+RR.v);
    
    //==================*********==================*********=============================//
    // global static variable-math op same class           // non static variable- math op same class
    int add=10+a;                                                int sub=100-RR.s;
    System.out.println("add operation value is "+add);   System.out.println("sub operation value is "+sub);
    
    int mul=10*a;                                                int div=80/RR.s;
    System.out.println("multi opration value is "+mul);  System.out.println("the division value is "+div);
    
  //==================*********==================*********=============================//
    // global static variable-math op other  class           // non static variable- math op other class
                                                             // create object for another class
                                                             Test121 RR2=new Test121() ;
                                                  
    	int add1=20+Test121.x;                                int multi=3*RR2.y;
    	
    	
    	
    	
    	
	}
    
    

	
	
	
	
}
