package inheritance________________9;

public class Testhomeminister extends Testchiefminister// extend from second super class



{
	
	
	public void ncp() {
		
		System.out.println("hello iam ajit pawar");
	}

}
