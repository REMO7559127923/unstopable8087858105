package inheritance________________9;

public class XXMULTILEVEL {
	
	public static void main(String[] args) 
	{
		XXSUPERCLASS SC=new XXSUPERCLASS();
		SC.superclass();
	
		System.out.println("===================");	
		
		
		
		X1SUBCLASS1  CS1= new X1SUBCLASS1();
		CS1.superclass();
		CS1.childclass();
		
		System.out.println("===================");	
		
		
		X2SUBCLASS2  CS2=new X2SUBCLASS2();
		CS2.superclass();
		CS2.childclass();
		CS2.childclass2();
		
	}
	
	

}
