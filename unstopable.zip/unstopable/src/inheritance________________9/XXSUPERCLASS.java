package inheritance________________9;

public class XXSUPERCLASS {

	public void superclass()
	{
		System.out.println("to provide properties to sub class");
	}
	
}
