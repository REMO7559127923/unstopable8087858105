package inheritance________________9;

public class Inheritancelevel // super class test
{
	
	public void primeminister()
	{
		System.out.println("hello iam prime minister");
	}
}
