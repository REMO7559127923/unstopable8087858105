package inheritance________________9;

public class X2SUBCLASS2 extends X1SUBCLASS1
{

	public void childclass2()
	{
		
	System.out.println("to brought properties from superclass depend upon level and hierical");	
	}
	
	
	
	
	
}
