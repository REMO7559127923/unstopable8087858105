package inheritance________________9;

public class XXSINGLELEVEL {
	
	
	
	public static void main(String[] args) {
		XXSUPERCLASS SC=new XXSUPERCLASS();
		
		SC.superclass();
		
	
		System.out.println("===================");	
		
		X1SUBCLASS1  CC=new X1SUBCLASS1();
		CC.childclass();
		
	}

}
