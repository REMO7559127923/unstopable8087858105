package inheritance________________9;

public class XXHIERARCHICAL {
	
	public static void main(String[] args) {
		XXSUPERCLASS SC=new XXSUPERCLASS();
		SC.superclass();
		
		
		
	    System.out.println("===================");	
	
	
	
		X1SUBCLASS1  CS1=new X1SUBCLASS1();
		SC.superclass();
		CS1.childclass();
	
		
		System.out.println("===================");		
		
		
		
		X3SUBCLASS   CS3=new X3SUBCLASS();
		CS3.superclass();
		CS3.childclass3();
		
		
		
	}

}
