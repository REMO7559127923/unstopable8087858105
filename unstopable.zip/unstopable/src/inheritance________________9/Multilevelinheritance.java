package inheritance________________9;

public class Multilevelinheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Inheritancelevel pm2= new Inheritancelevel();// superclass
		pm2.primeminister();
		
		Testchiefminister cm2=new Testchiefminister();// child class 1
		cm2.vote();
		cm2.primeminister();
		
		
		Testhomeminister hm=new Testhomeminister();// child class 2
		hm.ncp();//--cc2
		hm.vote();//--cc1
		hm.primeminister();//-sc
		
		
		

	}

}
