package inheritance________________9;

public class SInglelevelinheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Inheritancelevel pm1= new Inheritancelevel();//-superclass
		pm1.primeminister();
		System.out.println("========================");
		// super class properties can be use child class
		Testchiefminister cm1= new Testchiefminister();//-childclass1
		pm1.primeminister();//superclass own method
		cm1.vote();// own method
	    cm1.primeminister();
		System.out.println("========================");
		// super class properties can be use child class
		Testhomeminister hm1=new Testhomeminister();// tail class access all the super class properties
		hm1.primeminister();
		hm1.vote();
		hm1.ncp();// own method
		pm1.primeminister();//superclass own method
		
	}

}
