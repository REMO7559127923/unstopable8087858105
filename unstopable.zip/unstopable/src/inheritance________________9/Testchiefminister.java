package inheritance________________9;

public class Testchiefminister extends  Inheritancelevel// child class test

{
 public void vote()
 
 {
	 System.out.println("please vote me");
 }
	
}
