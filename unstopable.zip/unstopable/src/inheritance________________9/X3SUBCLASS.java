package inheritance________________9;

public class X3SUBCLASS  extends XXSUPERCLASS
{

	public void childclass3()
	{
		
	System.out.println("to get properties only super classs for hierarchical ");
	}
	
	
}
