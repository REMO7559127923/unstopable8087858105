package inheritance________________9;

public class X1SUBCLASS1 extends XXSUPERCLASS
{

public void childclass()
{
	System.out.println("to brought properties from superclass");
	
}
	
	
}
