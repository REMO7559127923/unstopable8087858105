package this_and_super___________________11;

public class ThisR1 {
	
	
	String name1="global variable 1";
	String name2="global variable 2";
	int a=10;
	int b=60;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  ThisR1 RR= new ThisR1();
  RR.THis();
	}
  
	public void THis() {
	String name1=" local variable 1";
	String name2="local variable 2";
	int a=100;
	int b=600;
	
	int add=a+b;//local operation
	
	System.out.println("local math operation "+add);// printing statement for local variable
	
	System.out.println("hello local  "+name1);
	System.out.println("hello local"+name2);
	
	System.out.println("gloabal math operation "+this.a*this.b);// printing statement for global variable
	
	System.out.println("HELLO GLOBAL "+this.name1      +this.name2);
	System.out.println("HELLO GLOBAL "+this.name2);

	
	}	
	
	
}
