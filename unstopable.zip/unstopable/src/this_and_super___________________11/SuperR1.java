package this_and_super___________________11;

public class SuperR1 extends ThisR1{// for super key this use key extend first

    int r=30;// gloabal variable
    int s=50;// global variable
    
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
     SuperR1 RRR= new SuperR1();
     RRR.SUper();
	}
    public void SUper() {
    	
    	int r=60;
    	int s=60;
    	
    	int multiplication=r*s;
    	
    	System.out.println("math operation local variable "+multiplication);// local variable printing statement 
    	
    	System.out.println("math operation global variable thisuse "+this.r*this.s);// global variable printing statement
    	
    	System.out.println("math operation global variable superuse "+super.a*super.b);// global variable printing statement another class
    	
    }
}
