package this_and_super___________________11;

public class Demo_kit2 {
public static void main(String[] args) {
	
}
}
