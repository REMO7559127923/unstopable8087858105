package this_and_super___________________11;

public class This_study {
	
	int a=20;// global variable
	int b=20;// global variable
	
	public static void main(String[] args) {
		
		This_study object=new This_study();
		object.mul2();
	}
	public void mul2() {
		int a=50;// local variable
		int b=50;// local variable
		
		int multi=a*b;//local math operation
		
		
		
		System.out.println("multiplication value local variable is  "+multi);//local math operation
		
		System.out.println("==========*****===========");
		
		System.out.println("multiplication of global variable is  "+this.a*this.b);//global variable math operation
		
		System.out.println("==========*****===========");
	}

	
	
	
	
	
}
