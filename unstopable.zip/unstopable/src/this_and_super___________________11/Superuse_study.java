package this_and_super___________________11;

public class Superuse_study extends This_study {
	
	int a=100;
	int b=20;
	
	public static void main(String[] args) {
		
		Superuse_study RM=new Superuse_study() ;
		RM.div();// create for same class
		
			
			
		
		
		
	}
	public void div() {
		
		int a=80;
		int b=20;
		
		int division1=a/b;
		System.out.println("my local variable division is  "+division1);//local variable math operation
		
		System.out.println("my global variable division is "+this.a/this.b);//global variable math operation with help of this use
		
		System.out.println("my global variable sup division is "+super.a/super.b);//global variable math operation another class  with help of super use
		
	
		
		
	}
	
	
	
	
	

}
