package generalisation_____________________15;

public class Shop1 implements Drink{

	@Override
	public void cocacola() {
		// TODO Auto-generated method stub
		System.out.println("cocacola 1000");
	}

	@Override
	public void sprite() {
		// TODO Auto-generated method stub
		System.out.println("sprite 2000");
		
	}

	@Override
	public void limca() {
		// TODO Auto-generated method stub
		System.out.println("limca 3000");
		
	}

	@Override
	public void pepsi() {
		// TODO Auto-generated method stub
		System.out.println("pepsi 4000");
	}
    
	public void milk() {
		System.out.println("milk 0 %");
	}
}
