package generalisation_____________________15;

public class Shop2 implements Drink{

	@Override
	public void cocacola() {
		// TODO Auto-generated method stub
		System.out.println("cocacola 5000");
	}

	@Override
	public void sprite() {
		// TODO Auto-generated method stub
		System.out.println("sprite  6000");
	}

	@Override
	public void limca() {
		// TODO Auto-generated method stub
		System.out.println("limca 7000");
		
	}

	@Override
	public void pepsi() {
		// TODO Auto-generated method stub
		System.out.println("pepsi 8000");
	}
    public void alcohol() {
    	System.out.println(" alcohol 0 %");
    	
    }
}
