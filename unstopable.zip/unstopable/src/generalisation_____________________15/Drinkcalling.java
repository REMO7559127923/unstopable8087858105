package generalisation_____________________15;

public class Drinkcalling {
	public static void main(String[] args) {
		Shop1 A1=new Shop1();
		Shop2 A2=new Shop2();
		A1.cocacola();
		A1.limca();
		A1.sprite();
		A1.pepsi();
		A1.milk();
		System.out.println("=======*=====*=====*====");
		A2.cocacola();
		A2.limca();
		A2.sprite();
		A2.pepsi();
		A2.alcohol();
		System.out.println("======*======*======*===");
		
		
		
		
	}
	
	
	

}
