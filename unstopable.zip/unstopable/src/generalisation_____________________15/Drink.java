package generalisation_____________________15;

public interface Drink {

	
	
	int alcohol=0;
    void cocacola();
    void sprite();
    void limca();
    void pepsi();
}
