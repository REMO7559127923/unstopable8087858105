package generalisation_____________________15;

public class GshopR1 implements GrocceryR1{

	@Override
	public void flour() {
		// TODO Auto-generated method stub
		System.out.println("wheat is 30 ₹ per kg");
	}

	@Override
	public void cosmetic() {
		// TODO Auto-generated method stub
		System.out.println("vicco turmeric is 150 ₹ per piece");
	}

	@Override
	public void snack() {
		// TODO Auto-generated method stub
		System.out.println("balaji snack 220 ₹ per kg");
	}

	@Override
	public void coldrinks() {
		// TODO Auto-generated method stub
		System.out.println("cocacola 1L bottle 90 ₹");
	}

	public void milk() {
		System.out.println("amul 1L bag 70 ₹ ");
	}
}
