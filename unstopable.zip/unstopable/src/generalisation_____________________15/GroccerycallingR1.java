package generalisation_____________________15;

public class GroccerycallingR1 {

	public static void main(String[] args) {
		GshopR1 YR1= new GshopR1();
		
		
		YR1.flour();
		YR1.cosmetic();
		YR1.coldrinks();
		YR1.snack();
		YR1.milk();
		
		System.out.println("=================================");
		
		GshopR2 YR2=new GshopR2();
		
		YR2.flour();
		YR2.cosmetic();
		YR2.coldrinks();
		YR2.snack();
		YR2.oil();
		System.out.println("================================");
	}
}
