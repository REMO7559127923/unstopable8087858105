package generalisation_____________________15;

public class GshopR2 implements GrocceryR1{

	@Override
	public void flour() {
		// TODO Auto-generated method stub
		System.out.println("rice is 60 ₹ per kg");
	}

	@Override
	public void cosmetic() {
		// TODO Auto-generated method stub
		System.out.println(" himalaya cosmetic 250 ₹ per piece ");
	}

	@Override
	public void snack() {
		// TODO Auto-generated method stub
		System.out.println(" gopal snack is 250 ₹ per kg");
	}

	@Override
	public void coldrinks() {
		// TODO Auto-generated method stub
		System.out.println("sprite 1.25 L bottle 110 ₹");
	}

	public void oil() {
		
	System.out.println("fortune cooking oil 200 ₹ per liter");
	}
}
