package generalisation_____________________15;

public interface GrocceryR1 {
          void flour();// incomplete method
          void cosmetic(); // incomplete method
          void snack(); // incomplete method
          void coldrinks(); // incomplete method
         
}
