package loopstudy______________8;

public class ForloopR1 {
	public static void main(String[] args) {
		// i want to print i love you 5 times
		for(int r=1;r<=5;r++) {
			System.out.println("i love you");
		}
		System.out.println("====================");
		for (int i=1; i<=10; i++) {
			System.out.println("do you love me");
		}
		System.out.println("====================");
		// i want print table of 5
		for(int k=5;k<=50;k=k+5) {
			System.out.println(k);
		}
		System.out.println("====================");
		// i want print table of 9
		for(int m=9;m<=90;m=m+9) {
			System.out.println(m);
		}
		System.out.println("=====================");
		// i want print table of 10
		for(int n=10;n<=100;n=n+10) {
		System.out.println(n);
		}
		System.out.println("=====================");
		// i want to print table reverse order 11
		for(int z=110;z>=11;z=z-11) {
			System.out.println(z);
		}
		System.out.println("=======================");
		// i want to print table reverse order 12
				for(int x=120;x>=12;x=x-12) {
					System.out.println(x);
				}
		
		System.out.println("=========================");
		
	}

}
