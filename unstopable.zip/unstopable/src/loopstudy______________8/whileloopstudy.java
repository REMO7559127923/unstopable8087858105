package loopstudy______________8;

public class whileloopstudy {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int x=1;
        while(x<=4)
        {
        System.out.println("avengers assemble");
        x++;
        }
        
        int y=1;
        while(y<=4)
        {
        System.out.println("endgame");
        y++;
        }
        //=========================================//
        //i want print table 7
        int a=7;
        
        while(a<=70)
        {
        	System.out.println(a);
            a=a+7;
       }
        System.out.println("=====================");
        //========================================//
      //i want print table 7 in reverse order
        int b=70;
        
        while(b>=7) 
        {
        	System.out.println(b);
        	b=b-7;
        }
        		
        System.out.println("=====================");
		
		
		
		
		
	}

}
