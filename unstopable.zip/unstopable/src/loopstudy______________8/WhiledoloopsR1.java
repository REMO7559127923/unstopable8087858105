package loopstudy______________8;

public class WhiledoloopsR1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a=1;
		do {
			System.out.println("i love you"+a);
			a++;}
		
		while(a<=5);
		System.out.println("=====================");
		// i want to print 18 table with help of do while
		
		
		int x=18;
		
		do {
			System.out.println(x);
			x=x+18;
		}
		while(x<=180);
		System.out.println("=======================");
		// i want to print 25 table with help of do while
		
		
		int y=25;
		do {
			System.out.println(y);
			y=y+25;
		}
		while(y<=250);
		System.out.println("=======================");
		
		// i want to print 23 table  reverse order with help of do while
		
		int z=230;
		
		do {
			System.out.println(z);
			z=z-23;
		}
		while(z>=23);
		
	}

}
