package loopstudy______________8;

public class WhileloopstudyR1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// i want to print i love you 6 time with the help of while loop
		int a=1;
		while(a<=6) {
			System.out.println("ilove you");
			a++;
		}
		// i want to print do you love me 10 time with the help of while loop   
		int b=1;
		while(b<=10) {
			System.out.println("do you love me ");
			b++;
			
		}
		// i want to print table 7
		int x=7;
		while(x<=70) {
			System.out.println(x);
			x=x+7;
		}
		// i want print table 13
		int y=13;
		while(y<=130) {
			
			System.out.println(y);
			y=y+13;
		}
		// i want print table 15
		int z=15;
		while(z<=150) {
			System.out.println(z);
			z=z+15;
		}
		
		// i want print table 20 reverse order
		int j=200;
		while(j>=20)
		{
			System.out.println(j);
			j=j-20;
			
		}
		// i want print table 30 reverse order
		int w=300;
		while(w>=30)
		{
		System.out.println(w);
		w=w-30;
		}
	}

}
