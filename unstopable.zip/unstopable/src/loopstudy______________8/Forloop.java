package loopstudy______________8;

public class Forloop {
public static void main(String[] args) {
	
	
	//I want to print Hello 5 times
	// start at 1 --> finish at 5
	//update by 1-->1,2,3,4,5,6,7,8,9,10-->a++==increament order
	// for(initialization; condition;updation)
	// {
	//
	// }
    
	for(int r=1; r<=2; r++)
	{
			System.out.println("avengers assemble");	
	}
	
	 
	for(int y=1; y<=3; y++)
	{
			
    		System.out.println("endgame");
	}
		
		//=======================================================//
		// i want to print table of 5
		for(int x=6;x<=60;x=x+6) {
			
			System.out.println(x);
		}
		System.out.println("=====================");
		//=======================================================//
		// i want to make reverse order of 5 table
		for(int z=50;z>=5;z=z-5) {
			
			System.out.println(z);
		}
		
		System.out.println("=====================");
		
		//===================================================//
		
		
		
		
		
	
}	

}
