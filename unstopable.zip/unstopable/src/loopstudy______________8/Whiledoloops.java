package loopstudy______________8;

public class Whiledoloops {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a=1;
		do {
			
			System.out.println("counting "+a);
			a++;
			}
		
		while(a<=10);
		//=======================================================//
				// i want to print table of 8
			
			int b=8;
		do {
			
			System.out.println("table of 8 is "+b);
			b=b+8;
		}
		while(b<=80);
		System.out.println("===========================");
		//=======================================================//
		// i want to print table of 8 in reverse  order
		
		int c=80;
		do {
			System.out.println("reverse order of table 8 is "+c);
			c=c-8;
		}
		while(c>=8);
		
		
			
		
		
	

	}

}
