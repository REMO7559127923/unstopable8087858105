package A0_occurance_DupCOunt_Sum;

import java.util.HashMap;
import java.util.Map;

public class char_occurance___A {
public static void main(String[] args) {
	
String str="Raahulvasantbadgujar";


Map<Character, Integer> logic=new HashMap<>();

for(char ch :str.toCharArray()) {
	logic.put(ch, logic.getOrDefault(ch, 0)+1);
}
	System.out.println("the charcter occurance is :"+logic);
	
	
	
	
	
	
}
	
	
	
	

}
