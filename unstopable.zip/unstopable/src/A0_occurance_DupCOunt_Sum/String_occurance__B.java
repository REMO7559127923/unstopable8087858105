package A0_occurance_DupCOunt_Sum;

import java.util.HashMap;
import java.util.Map;

public class String_occurance__B {
	public static void main(String[] args) {
		
	
	String str="i love you renuka sonawale";
	
	String[] input=str.split(" "); 
	
	
	
	Map<String , Integer> logic=new HashMap<>();
	
	
	for(String sr:input) {
		
logic.put(sr, logic.getOrDefault(sr, 0)+1);		
	}

System.out.println(" the given string occrance is : "+logic);
}}
