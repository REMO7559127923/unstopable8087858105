package A0_occurance_DupCOunt_Sum;

import java.util.HashMap;
import java.util.Map;

public class NumberDuplicate_count {
	public static void main(String[] args) {

		int[] number = { 1, 2, 2, 2, 2, 3, 3, 5, 5, 5, 5, 5, 6, 7 };

		Map<Integer, Integer> logic = new HashMap<>();

		for (int nr : number) {
			logic.put(nr, logic.getOrDefault(nr, 0) + 1);
		}
// to print duplicate number count 

		for (int printnum : logic.keySet()) {
			if (logic.get(printnum) > 1) {
				System.out.println("the given number " + printnum + "   is the  :  " + logic.get(printnum));
			}
		}

	}
}