package A0_occurance_DupCOunt_Sum;

import java.util.HashMap;
import java.util.Map;

public class Number_ocurance {
	public static void main(String[] args) {
		
	
	
	int [] number= {1,2,3,4,5,6,7,8,1,2,3,4,5,6};
	
	
	
	Map<Integer, Integer> logic=new HashMap<>();
	
	
	for(int nr:number) {
		logic.put(nr, logic.getOrDefault(nr, 0)+1);
		
	}
System.out.println(" the given number occrance is "+logic);
}}
