package A0_occurance_DupCOunt_Sum;

import java.util.HashMap;
import java.util.Map;

public class Charcter_DupliacteCount {
public static void main(String[] args) {
	String str="rahulbadgujar";
	//char[] input=str.toCharArray();
	Map<Character, Integer> logic=new HashMap<>();
	for(char cr:str.toCharArray()) {
		
		logic.put(cr, logic.getOrDefault(cr, 0)+1);
		
	}
	
	for(Character printcr:logic.keySet()) {
		if(logic.get(printcr)>1) {
			System.out.println("the given duplicate character   "+printcr+" count is "+logic.get(printcr));
		}
	}
	
}
}
