package A0_occurance_DupCOunt_Sum;

import java.util.HashMap;
import java.util.Map;

import java.util.HashMap;
import java.util.Map;

public class NumberDuplicateSum {
    public static void main(String[] args) {
        int[] number = {1, 2, 2, 2, 2, 3, 3, 5, 5, 5, 5, 5, 6, 7};

        Map<Integer, Integer> logic = new HashMap<>();
        int totalSum = 0;

        // Count occurrences
        for (int nr : number) {
            logic.put(nr, logic.getOrDefault(nr, 0) + 1);
        }

        // Calculate and print individual sums and accumulate total sum
        for (int printnum : logic.keySet()) {
            if (logic.get(printnum) > 1) { // Only consider duplicates
                int sum = printnum * logic.get(printnum);
                totalSum += sum; // Add to total sum
                System.out.println("The number " + printnum + " appears " + logic.get(printnum) + " times, and its sum is: " + sum);
            }
        }

        // Print the total sum of all duplicate numbers
        System.out.println("The total sum of all duplicate numbers is: " + totalSum);
    }
}
