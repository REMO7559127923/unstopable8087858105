package A0_occurance_DupCOunt_Sum;

import java.util.HashMap;
import java.util.Map;

import java.util.HashMap;
import java.util.Map;

public class String_DuplicateCountDone {
    public static void main(String[] args) {
        String str = "java java kya he drmaa";
        String[] input = str.split(" ");
        
        Map<String, Integer> logic = new HashMap<>();
        
        // Counting occurrences of each word
        for (String sr : input) {
            logic.put(sr, logic.getOrDefault(sr, 0) + 1);
        }
        
        // Printing duplicate counts using keySet
        for (String printsr : logic.keySet()) {
            if (logic.get(printsr) > 1) {
                System.out.println("The given string duplicate count for '" + printsr + "' is: " + logic.get(printsr));
            }
        }
    }
}
