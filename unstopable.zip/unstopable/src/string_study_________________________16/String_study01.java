package string_study_________________________16;

public class String_study01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//length method
		String s="RAHULaarya";
		// 1st way to print string length
		System.out.println("String length is "+s.length());//
		
		String r="RENUKA";
		// 1st way to print string length
		System.out.println("String length is "+r.length());//
		
		System.out.println("============================");
		// 2nd way to print string length
		int printtolength=s.length();
		System.out.println("string lenghth is"+printtolength);
		
		int printtolength2=r.length();
		System.out.println("string length is "+printtolength2);//
		
		System.out.println("=============================");
		
		String q="a p p l e";
		
		System.out.println(q.length());
		
		System.out.println("=============================");
		// Uppercase to Lowercase----->
		
		
       
        
        String N=s.toUpperCase();
        System.out.println(N);
       System.out.println("================================"); 
        String n=s.toLowerCase();
        System.out.println(n);
        System.out.println("===============================");
        // equal method
        String x1="Pune";
        String y="Pune";
        String p= new String("Pune");
        String r1= new String("PunR");
        String z=new String("PUNE");
        System.out.println(x1==y);//true
        System.out.println(x1==p);//false ** new keyword = work nhi krta
        System.out.println(p==r1);//false
        System.out.println("===============================");
        
        System.out.println(x1.equals(y));//true
        System.out.println(x1.equals(p));//true
        System.out.println(r1.equals(z));//false
        // cantains
        System.out.println("============cantains==================");
        String s3="Velocity";
        System.out.println(s3.contains("city"));
        
        System.out.println(s3.contains("ytic"));// reverse
        
      //using ref variable
        boolean result = s3.contains("e");
        System.out.println("result is "+result);
        System.out.println("================================");
       // // isEmpty()----> 
        String a1="Pune";
        String a2="";
        String a3=" ";// space bhi matter krta hai isempty me
        System.out.println("a1 result is "+a1.isEmpty());
        System.out.println("a2 result is "+a2.isEmpty());
        System.out.println("a3 result is "+a3.isEmpty());
        
        System.out.println("================================");
        
        System.out.println("a1 result is "+a1.isBlank());
        System.out.println("a2 result is "+a2.isBlank());//character ho ya na ho matter krta hai
        System.out.println("a3 result is "+a3.isBlank());
        
       System.out.println("================================="); 
        // char boat
        
        String b="Velocity";
        System.out.println(b.charAt(0));
        System.out.println(b.charAt(1));
        System.out.println(b.charAt(2));
        System.out.println(b.charAt(3));
        System.out.println(b.charAt(4));
        System.out.println(b.charAt(5));
        //using ref variable
        char answer= b.charAt(0);
        char ans = b.charAt(1);
        char ans1 = b.charAt(2);
        char ans2 = b.charAt(3);
        char ans3 = b.charAt(4);
        char ans4 = b.charAt(5);
        System.out.println("Ans is "+answer);
        System.out.println("Ans is "+ans);
        System.out.println("Ans is "+ans1);
        System.out.println("Ans is "+ans2);
        System.out.println("Ans is "+ans3);
        System.out.println("Ans is "+ans4);
        
     System.out.println("===================================");   
        
                      
     // endsWith(),startsWith() method use----> 
        String c= "Maharashtra";
        System.out.println(c.endsWith("Maharashtra"));
        System.out.println(c.startsWith("Maha"));
        System.out.println(c.startsWith("aha",1));//define kr skte position
      System.out.println("================================");
      // substring method
    System.out.println(c.substring(3));
    System.out.println(c.substring(1,7));
	}
     
}
