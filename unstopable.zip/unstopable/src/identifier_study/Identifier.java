package identifier_study;

public class Identifier {

}
