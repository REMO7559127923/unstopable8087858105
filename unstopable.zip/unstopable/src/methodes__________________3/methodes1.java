package methodes__________________3;

public class methodes1 {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		mathuse1();// calling static method in main method
		System.out.println("==============================");
		 methodes1 rm= new  methodes1();// create object for non static method calling in main method
		rm.mathuse2();// calling non static method in main method
		System.out.println("==============================");

		Test1.name();// calling static method from another class in main method
		System.out.println("==============================");

		Test1 ab = new Test1();//create object for non static method from another class
		ab.surname();//calling non static method from another class in main method
		System.out.println("==============================");

		
		
		
	}
	
	
	
	
	public static void mathuse1() {//static method
		
		int a=10;
		int b=20;
		 int sum=a+b;
		 System.out.println("my adddition is "+sum);
		  
		 
		 long c=8624062433l;
		 long d=7020088764l;
		  long sum1=c+d;
		  System.out.println("my addition of mobile number "+sum1);
		  
		  float e=5.1f;
		  float f=4.3f;
		  float mul=e*f;
		  System.out.println("my multiplication of decimal number is "+mul);
		  
		  double g=125.2654854d;
		  double h=421.3625548d;
		  double div=h/g;
		  System.out.println("my division of decimal number is "+div);
		
	}
	
	
	
	public void mathuse2() // non static method
	{
		
		int a=10;
		int b=20;
		 int sub=a-b;
		 System.out.println("my adddition is "+sub);
		  
		 
		 long c=8624062433l;
		 long d=7020088764l;
		  long add=c+d;
		  System.out.println("my addition of mobile number "+add);
		  
		  float e=5.1f;
		  float f=9.3f;
		  float mul=e*f;
		  System.out.println("my multiplication of decimal number is "+mul);
		  
		  double g=825.2654854d;
		  double h=421.3625548d;
		  double div=g/h;
		  System.out.println("my division of decimal number is "+div);
		
		
		
		
		
		
		
		
	}


}
