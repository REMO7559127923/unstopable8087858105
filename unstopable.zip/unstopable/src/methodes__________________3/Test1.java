package methodes__________________3;

public class Test1 {
public static void name() {
		
		String name="rahul";
		System.out.println("my name is "+name);
		
	}
	
	public void surname() {
		
		String surname="badgujar";
		System.out.println("my surname is "+surname);
	}

}
