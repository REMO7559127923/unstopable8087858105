package methodes__________________3;

public class Another_TEST1 {
	public static void P1 ()
	{
		int A=1600;
		int B=1700;
		 int sum=A+B;
		 System.out.println("ADDITION VALUE IS "+sum);
		 
		double A1=256.2564866845d;
		double B1=869.1235256655d;
		
		double division=B1/A1;
		 
		System.out.println("DIVISION VALUE IS "+division);
		
		
	}
	public  void P2()
	{
		

		 float C=15.6f;
		 float D=19.2f;
		 float sub=C-D;
		 System.out.println("SUBTRACTION VALUE IS "+sub);
		 
		 long E=8624062433l;
		 long F=7020088764l;
		 
		 long add=E+F;
		 System.out.println("ADD VALUE IS "+add);

		
		
	}
}
