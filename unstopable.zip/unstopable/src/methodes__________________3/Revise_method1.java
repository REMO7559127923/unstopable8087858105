package methodes__________________3;

public class Revise_method1 {
	
	public static void main(String[] args) {
		
		m1();// same class method calling in main method
		
		// same class non static method calling in main method
		// create object 
		// same classname object= new same classname
		Revise_method1 R=new Revise_method1();
		R.m2();
		
		System.out.println("===============================");
		
		
		
		Another_TEST1.P1();// another class static method calling in main method
		// create another class object
		// another class name  object = new  another class name
		
		Another_TEST1 R2= new Another_TEST1(); 
		R2.P2();
		System.out.println("================================");
		
		
		
		
	}
public static void m1 ()
{
	int A=600;
	int B=700;
	 int sum=A+B;
	 System.out.println("ADDITION VALUE IS "+sum);
	 
	double A1=123.2564866845d;
	double B1=456.1235256655d;
	
	double division=B1/A1;
	 
	System.out.println("DIVISION VALUE IS "+division);
}
public  void m2()
{
	

	 float C=8.6f;
	 float D=9.2f;
	 float sub=C-D;
	 System.out.println("SUBTRACTION VALUE IS "+sub);
	 
	 long E=8624062433l;
	 long F=7711998484l;
	 
	 long add=E+F;
	 System.out.println("ADD VALUE IS "+add);

	
	
}
	
	
	
	
}
