package DO_or_DIE;

public class A2_swap_the_StringNumbers {

	public static void main(String[] args) {
		int num1=20;
		int num2=10;
String s1=String.valueOf(num1);
String s2=String.valueOf(num2);


// with substring 
s1=s1+s2;
s2=s1.substring(0,s1.length()-s2.length());
s1=s1.substring(s2.length());
System.out.println(s1+" "+s2);


//without using third variable 

String s3="raahul";
String s4="badgujar";

s3=s3+s4;
s4=s3.replaceFirst(s4, "");
s3=s3.replaceFirst(s4, "");

System.out.println(s3+" "+s4);
		// using with third variable
String s5="renuka";
String s6="sonawale";

//swap 
String temp=s5;
s5=s6;
s6=temp;

System.out.println(s5+" "+s6);




	}

}
