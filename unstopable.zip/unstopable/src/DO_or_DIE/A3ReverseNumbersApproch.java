package DO_or_DIE;

public class A3ReverseNumbersApproch {
	public static void main(String[] args) {
		int num = 1234;
		// reverse the number

		int rev = 0;
		while (num > 0) {
			rev = rev * 10 + num % 10;
			num = num / 10;
		}

		System.out.println(rev);
		
		// with string builder
		int num2=5678;
		String orignal=String.valueOf(num2);
		StringBuilder sb=new StringBuilder();
		String result=sb.append(orignal).reverse().toString();
		System.out.println(result);
		//with string buffer
		StringBuffer sb2=new StringBuffer(orignal);
		String result2=sb2.reverse().toString();
           System.out.println(result2);
		

	}

}
