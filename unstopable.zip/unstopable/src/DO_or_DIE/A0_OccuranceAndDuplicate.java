package DO_or_DIE;

import java.util.HashMap;
import java.util.Map;

public class A0_OccuranceAndDuplicate {
	public static void main(String[] args) {
		String str="Hello World Hello World i";
		String []input=str.split(" ");
		int maxcount=0;
		String maxstring=" ";
		
		Map<String,Integer> logic=new HashMap<>();
        for(String ch:input) {
        	logic.put(ch, logic.getOrDefault(ch, 0)+1);
        	if(logic.get(ch)>maxcount) {
        		maxstring=ch;
        		maxcount=logic.get(ch);
        	}
        }
        System.out.println(" the given count ocurance  "+logic);
        System.out.println("the given charcter :"+maxstring+"  :and count is "+maxcount);
        //for duplicate count
        for(String printch:logic.keySet()) {
        	if(logic.get(printch)>1) {
        		System.out.println("the duplicate count in given string "+printch+" : is "+logic.get(printch));
        	}
        }
	}

}
