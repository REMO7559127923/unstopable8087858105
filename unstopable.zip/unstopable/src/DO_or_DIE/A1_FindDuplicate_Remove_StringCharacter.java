package DO_or_DIE;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public class A1_FindDuplicate_Remove_StringCharacter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "Hello World Hello World i";
		String input = str.replace(" ", "");
		Set<Character> unique = new HashSet<>();
		Set<Character> duplicate = new HashSet<>();
		StringBuilder sb = new StringBuilder();
		for (char logic : input.toCharArray()) {
			if (unique.add(logic)) {
				duplicate.add(logic);
				sb.append(logic);
			}
		}

		System.out.println(sb.toString());

		// for remove duplicate string
		String[] input2 = str.split(" ");
		LinkedHashSet<String> unique2 = new LinkedHashSet<>();
		for (String logic2 : input2) {
			unique2.add(logic2);

		}
		
		System.out.println(unique2);
		
		//for remove duplicate number 
		int num=1223334455;
		String input3=String.valueOf(num);
		LinkedHashSet<Character> Unique3=new LinkedHashSet<>();
		for(char logic3:input3.toCharArray()) {
			Unique3.add(logic3);
			
		}
		System.out.println(Unique3);
		
		

	}

}
