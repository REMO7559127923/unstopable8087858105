package DO_or_DIE;

public class A3_ReverseStringApproches {

	public static void main(String[] args) {

		String str = "mom";

		String rev = "";
		for (int i = str.length() - 1; i >= 0; i--) {
			char txt = str.charAt(i);
			rev = rev + txt;

		}
		System.out.println("the given string " + str + "  : is  :" + (str.equals(rev) ? "paildrome" : "non paildrome"));

// with stringBuilder
		StringBuilder sb = new StringBuilder();
		String result = sb.append(str).reverse().toString();

		System.out.println(
				"the given string " + str + "  : is  :" + (str.equals(result) ? "paildrome" : "non paildrome"));

//with string buffer
		StringBuffer stb = new StringBuffer(str);
		String result2 = stb.reverse().toString();
		System.out.println(
				"the given string " + str + "  : is  :" + (str.equals(result2) ? "paildrome" : "non paildrome"));

	}

}
