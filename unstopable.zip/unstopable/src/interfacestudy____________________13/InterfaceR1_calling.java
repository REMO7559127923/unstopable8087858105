package interfacestudy____________________13;

public class InterfaceR1_calling implements InterfaceR1_1,InterfaceR2_2{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
           InterfaceR1_calling YR= new InterfaceR1_calling();
           YR.singer();
           YR.hero();
           YR.movie();
           YR.song();
           YR.city();
           YR.name1();
           InterfaceR1_1.state();// static method with the help of class name
           InterfaceR2_2.name2();// static method with the help of class name
           
	}

	@Override
	public void singer() {
		// TODO Auto-generated method stub
		System.out.println("arjit singh");
		
	}

	@Override
	public void hero() {
		// TODO Auto-generated method stub
		System.out.println("emran hashmi");
	}

	@Override
	public void movie() {
		// TODO Auto-generated method stub
		System.out.println("hamari adhuri kahani");
	}

	@Override
	public void song() {
		// TODO Auto-generated method stub
		System.out.println("ha hasi ban gaye");
	}

}
