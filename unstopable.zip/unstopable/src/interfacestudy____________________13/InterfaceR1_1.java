package interfacestudy____________________13;

public interface InterfaceR1_1 {
	
	void movie();
	void song();
	
	
	default void city() {
		
		System.out.println("the city is nashik");
		
	}
    static void state () {
    	
    	System.out.println("maharashtra");
    }
}
