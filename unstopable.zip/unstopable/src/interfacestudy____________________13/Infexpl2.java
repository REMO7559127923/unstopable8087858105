package interfacestudy____________________13;

public interface Infexpl2 extends Infexpl1
{

	void add();
	void mul() ;
	
	
}
