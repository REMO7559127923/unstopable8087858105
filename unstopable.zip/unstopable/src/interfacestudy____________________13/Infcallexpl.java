package interfacestudy____________________13;

public class Infcallexpl implements Infexpl2 {

	
	public static void main(String[] args) {
		
		Infcallexpl RM= new Infcallexpl();
		RM.add();// interface calling Infexpl2
		RM.sub();// interface calling Infexpl1
		RM.mul();// interface calling Infexpl2
		RM.div();// interface calling Infexpl1
		
		
	}
	
	
	
	
	
	@Override
	public void sub() {
		// TODO Auto-generated method stub
		System.out.println(" the value of subtarction is ");
	}

	@Override
	public void div() {
		// TODO Auto-generated method stub
		System.out.println("the value of division is ");
	}

	@Override
	public void add() {
		// TODO Auto-generated method stub
		System.out.println("the value of addition is ");
	}

	@Override
	public void mul() {
		// TODO Auto-generated method stub
		System.out.println("the value of multiplication");
	}

}
