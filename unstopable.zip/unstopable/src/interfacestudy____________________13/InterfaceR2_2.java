package interfacestudy____________________13;

public interface InterfaceR2_2 {
	
	void singer ();
	void hero ();
	
	default void name1() {
		
		System.out.println("my name is rahul");
		
	}
 static void name2() {
	 System.out.println("my name is renuka");
 }
}
