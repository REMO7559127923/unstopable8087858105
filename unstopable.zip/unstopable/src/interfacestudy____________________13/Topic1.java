package interfacestudy____________________13;

public interface Topic1 {

 void ODI();
 void T20();
 void TEST();
	
	
	
	
}
