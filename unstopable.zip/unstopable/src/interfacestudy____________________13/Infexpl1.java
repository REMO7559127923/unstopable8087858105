package interfacestudy____________________13;

public interface Infexpl1  {
	
	void sub();
	void div();

}
