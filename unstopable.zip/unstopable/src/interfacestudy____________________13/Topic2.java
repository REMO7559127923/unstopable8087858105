package interfacestudy____________________13;

public class Topic2 implements Topic1
{

	
	public static void main(String[] args) {
		Topic2 RM=new Topic2();
		RM.ODI();// interface calling from interface class with help of override
		RM.T20();// interface calling from interface class with help of override
		RM.TEST();// interface calling from interface class with help of override
		ranji();   // static ----> // interface calling from interface class own method
		RM.gully();// non static --->// interface calling from interface class own method
	}
	
	
	
	
	@Override
	public void ODI() {
		// TODO Auto-generated method stub
		System.out.println("50 over match");
	}

	@Override
	public void T20() {
		// TODO Auto-generated method stub
		System.out.println("20 over match");
	}

	@Override
	public void TEST() {
		// TODO Auto-generated method stub
		System.out.println(" 5 days match");
	}

    public static void ranji() {
    	
    	System.out.println("domestic cricket");
    }
	
    public void gully () {
    	System.out.println("gully cricket");
    	
    }
    
}
