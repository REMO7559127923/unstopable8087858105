package A5_min_max_longest;

import java.util.Arrays;

public class StringSecond_largestDone {

	public static void main(String[] args) {
		String str = "raaahull badgujar i love renuka" ;
				String[] input = str.split(" ");
//		Arrays.sort(input);
//		String sl=input[input.length-1];
//		System.out.println("sl "+sl);

		String longest = input[0];
		String Slargest = input[0];

		for (String logic : input) {
			if (logic.length() > longest.length()) {
				Slargest=longest;
				longest=logic;

			}
			else if(logic.length()>Slargest.length() && logic.length()!=longest.length()) 
			{
				Slargest=logic;
			}

		}

		

		System.out.println("the given string array longest string is "+longest);
		System.out.println("the given string array Secondlargest string is "+Slargest);
	}

}
