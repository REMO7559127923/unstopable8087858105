package A5_min_max_longest;

import java.util.Arrays;

public class secondmax_number { 
	public static void main(String[] args) {
	//Aproch -1


	int []number1= {1,2,3,4,5,6,7,8};
	
	Arrays.sort(number1);
	int secondlargest=number1[number1.length-2];
	System.out.println("Approch1    second largest number: "+secondlargest);
	
	//Approch -2
	int []number= {1,2,3,4,5,6,7,8};
	
	int max=Integer.MIN_VALUE;
	int smax=Integer.MIN_VALUE;
	
	for(int logic:number) {
		if(logic>max) {
			smax=max;
			max=logic;
		}
		else if(logic>smax && logic!=max) {
			smax=logic;
		}
	}
	
	System.out.println("the given maximum number is "+max);
	System.out.println("the given second maximum number is "+smax);
}}
