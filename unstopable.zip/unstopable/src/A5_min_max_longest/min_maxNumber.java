package A5_min_max_longest;

public class min_maxNumber {
	public static void main(String[] args) {
		
	

	int[] number= {1,2,3,4,5,6};
	
	int max=number[0];
	int min=number[0];
	
	
	
	for(int logic :number) {
		
		
		
		if(logic>max) {
			max=logic;
		}
		if(logic<min) {
			min=logic;
			
		}
	}
	System.out.println(" the given array maximum number is "+max);
	System.out.println(" the given array minimum number is "+min);

	
	}
}
