package abstract_study____________________12;

public  class Atestclass extends Atest_study
{
	
public static void main(String[] args) {
	
	Atestclass RM = new Atestclass();
	RM.sub();
	RM.name();
	
}

@Override
public void sub() {
	// TODO Auto-generated method stub
	int subtract =a-b;
	System.out.println(" the sub value is "+subtract);
}

@Override
public void name() {
	// TODO Auto-generated method stub
	System.out.println(" my name is rahul");
}
	
	
	
	
}
