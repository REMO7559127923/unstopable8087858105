package abstract_study____________________12;

public class AbstractR1calling extends AbstractR1info{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         AbstractR1calling YR=new AbstractR1calling();
         YR.add(); // calling abstract method  own complete body
         YR.mul();//  calling abstract method incomplete body
         YR.sub();// calling abstract method incomplete body
	}

	@Override
	public void sub() {
		// TODO Auto-generated method stub
		int sub1=r-y;
		System.out.println("subtraction  "+sub1);
	}

	@Override
	public void mul() {
		// TODO Auto-generated method stub
		int mul1=r*y;
		System.out.println("multiplication  "+mul1);
	}

}
