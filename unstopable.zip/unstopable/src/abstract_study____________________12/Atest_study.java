package abstract_study____________________12;

public abstract class Atest_study {
	
	int a=50;// global variable
	
	int b=60;// global variable
	
	public static void main(String[] args) {
		
		// in abstract object does not create due 
		
	}
	
	
	
	public  void add() {// methode with compltete body but does not calling due to another methode has abstract;
		
		int a=10;
		int b=20;
		int sum=a+b;
		System.out.println("my addition value is  "+sum);
		
	}
	
	public abstract void sub();// incomplte body without code block curly bracket end with semi collen;
	
	public abstract  void name();// incomplte body without code block curly bracket end with semi collen; 
	
	

}
