package abstract_study____________________12;

public abstract class AbstractR1info {
	
	
	    int y=10;
	    int r=20;
	    

	

	public void add()// methode with complete body
	{
		
		int y=50;
		int r=80;
		
		int add=y+r;

     System.out.println("addition value is "+add);
	}
	public abstract void sub();// method with incomplete body
	
	public abstract void mul();//method with incomplete body
	
	
	
	
	
}
