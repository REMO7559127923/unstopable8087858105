package methoswithparameter______________4;

public class Methodswithparameter {
	
	public static void main(String[] args) {
		
		add();
		
		add1(500);
		add2(500, 500);
		add3(500, 500, 500);
		
		
		
		Methodswithparameter RR=new Methodswithparameter();
		RR.mul1(1000);
		RR.mul2(1000, 1000);
		RR.mul3(100, 2, 2);
		
	}
	
	
	public static void add()
	{
		int a=30;
		int b=30;
		int c=30;
		int d=30;
		
		int sum=a+b+c+d;
		System.out.println("the add is "+sum);// zero parameter
	}

	
	
	public static void add1(int a) {
		int a1=a;
		System.out.println("one parameter value "+a1);
	}
	public static void add2(int a, int b ) {
		int a2=a+b;
		System.out.println("two parameter value "+a2);
	}
	public static void add3(int a, int b, int c) {
		int a3=a+b+c;
		System.out.println("three parameter value "+a3);
	}
	
	
	public void mul1(int r) {
		int r1=r;
		System.out.println("one parameter value "+r1);
	}
	public void mul2(int r, int s) {
		int r2=r*s;
		System.out.println("two parameter value "+r2);
		}
	public void mul3(int r,int s,int t) {
		int r3=r*s*t;
		System.out.println("three parameter value "+r3);
	}
}
