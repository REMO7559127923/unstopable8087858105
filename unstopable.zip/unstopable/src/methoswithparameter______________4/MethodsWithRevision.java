package methoswithparameter______________4;

public class MethodsWithRevision {
	public static void main(String[] args) {
		data1("Rahul", 100, 'A', 60);
		data1("shirikant", 90, 'A', 65);
		data1("manoj", 50, 'A', 55);
		
		
		
	}
	public static void data1(String name, int RollNo, char grade, float per) {
		System.out.println("----------student info-------------");
		System.out.println("student name: " + name);
		System.out.println("student RollNo: " + RollNo);
		System.out.println("student grade: " + grade);
		System.out.println("student per: " + per);
		
		
		
	}

}
