package methoswithparameter______________4;

public class Parameteroperations {

	public static void main(String[] args) {
		add();// calling for zero parameter----->static parameter
		mul(50, 50);// calling for 2 parameter---->static parameter
		mul1(15, 15, 15);// calling for 3 parameter---->static parameter
		sub(500, 50, 30, 20);// calling for 4 parameter---->static parameter
		//======================================/
		//create object for non static method//
		Parameteroperations RR=new Parameteroperations();
				
		        RR.addN();// calling for zero parameter----->static parameter
				RR.mulN(40, 40);// calling for 2 parameter---->static parameter
				RR.mul1N(60, 60, 60);// calling for 3 parameter---->static parameter
				RR.subN(1000, 500, 200, 100);// calling for 4 parameter---->static parameter
		
		
		
	}
	public static void add()
	{
		int a=20;
		int b=30;
		int c=40;
		int d=50;
		
		int sum=a+b+c+d;
		System.out.println("the add is "+sum);// zero parameter
	}
	public static void mul (int a,int b) 
	{
		int mul=a*b;
		
		System.out.println("multiplication is "+mul);//two parameter
		
	}
		
	public static void mul1 (int a,int b,int c) 
	{
		int mul1=a*b*c;
		
		System.out.println("multiplication is "+mul1);//three parameter
		
	}	
		
	public static void sub (int a,int b,int c,int d) 
	{
		int sub=a-b-c-d;
		
		System.out.println("multiplication is "+sub);//four parameter
		
	}		
		
		
	public void addN()
	{
		int r=50;
		int s=60;
		int t=70;
		int q=80;
		
		int sum=r+s+t+q;
		System.out.println("the add is "+sum);// zero parameter
	}
	public  void mulN (int r,int s) 
	{
		int mul=r*s;
		
		System.out.println("multiplication is "+mul);//two parameter
		
	}
		
	public  void mul1N (int r,int s,int t) 
	{
		int mul=r*s*t;
		
		System.out.println("multiplication is "+mul);//three parameter
		
	}	
		
	public  void subN (int r,int s,int t,int q) 
	{
		int sub=r-s-q-t;
		
		System.out.println("multiplication is "+sub);//four parameter
		
	}		
	
	
	
	
	
}
