package A8_Substring;

public class StringProcessorPracticeDone {

    public static void main(String[] args) {
        // Sample array of strings
        String[] input = { "apple", "banana", "Cherry", "DATE", "Zebra", "ORANGE", "quiz" };

        // Iterate over the array and process each string
        for (String logic : input) {
            StringBuilder sb = new StringBuilder(logic + ": ");

            // Append "EVEN" or "ODD" based on string length
            if (logic.length() % 2 == 0) {
                sb.append("EVEN ");
            } else {
                sb.append("ODD ");
            }

            // Check if the string contains any vowels (both uppercase and lowercase)
            if (logic.matches(".*[AEIOUaeiou].*")) {
                sb.append("VOWEL ");
            }

            // Check if the string contains the letter 's'
            if (logic.toLowerCase().contains("z")) {
                sb.append("has_Z");
            }

            // Print the result for the current string
            System.out.println(sb.toString().trim());
        }
    }
}
