package A3_Reverse;

public class Reverse_Numberwith_logicalcalculation {
	
	
	public static void main(String[] args) {
		int num=1234;
		int rev=0;
		
		
		
	while(num>0) {
		
		
		
		
		rev=rev*10+num%10;
		num=num/10;
		
	}
		System.out.println("the given number is reversed : "+rev);
		
		
	}

}
