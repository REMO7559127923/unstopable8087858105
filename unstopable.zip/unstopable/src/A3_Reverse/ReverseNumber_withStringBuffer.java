package A3_Reverse;

import java.util.Scanner;

public class ReverseNumber_withStringBuffer {

	public static void main(String[] args) {
		int num=1234;
		
		StringBuffer sb=new StringBuffer(String.valueOf(num));
		StringBuffer reversenum=sb.reverse();
		
		System.out.println("reversenum:"+reversenum);
		}
	 
	}


