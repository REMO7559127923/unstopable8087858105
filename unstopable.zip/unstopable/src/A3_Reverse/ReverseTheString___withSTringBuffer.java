package A3_Reverse;

import java.util.Scanner;

import org.openqa.selenium.remote.ExecuteMethod;

public class ReverseTheString___withSTringBuffer {

	public static void main(String[] args) {
		String str = "mom";

		StringBuffer sb = new StringBuffer(str);
		StringBuffer reversed = sb.reverse();

		System.out.println(" the reversed  string is " + reversed);
	System.out.println(str.equalsIgnoreCase(reversed.toString())?"paildome":"not paildrome");
		
		
		
	}

}
