package A3_Reverse;

import java.util.Scanner;

public class ReverseNumber_withStringBuilder {

	public static void main(String[] args) {
		int num=1234;
		
	
	StringBuilder sb=new StringBuilder();
			sb.append(num).reverse();
	System.out.println("the  reverse number is "+sb);
	
	}
	 
	}


