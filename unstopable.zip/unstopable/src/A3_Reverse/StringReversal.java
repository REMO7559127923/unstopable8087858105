package A3_Reverse;

import org.apache.commons.lang3.text.StrBuilder;

public class StringReversal {
    public static void main(String[] args) {
        // Input string
        String input = "hello world";
        
       String firstpart = input.substring(0, 5);//rahul
       String secondpart = input.substring(5,6);//vasant

       String thirdpart = input.substring(6 );//badgujar
       
       String part1=new StringBuilder(firstpart).reverse().toString();
       String part3=new StringBuilder(thirdpart).reverse().toString();


       
        
        

       

        

        // Concatenate the reversed segments
        String output = firstpart + secondpart + part3;

        // Output the final transformed string
        System.out.println("Transformed string: " + output);
    }
}
