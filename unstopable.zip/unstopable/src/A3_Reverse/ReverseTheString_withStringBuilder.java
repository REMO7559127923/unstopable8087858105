package A3_Reverse;

public class ReverseTheString_withStringBuilder {
	public static void main(String[] args) {
		String str ="momy";
		StringBuilder sb=new StringBuilder();
		String result=sb.append(str).reverse().toString();
	System.out.println(" the string is reversed "+sb);
	System.out.println(str.equals(result) ? "paildrome" : "not paildrome");
	}

}
