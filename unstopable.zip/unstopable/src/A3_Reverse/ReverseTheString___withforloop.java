 package A3_Reverse;

import java.util.Scanner;

import org.openqa.selenium.remote.ExecuteMethod;

public class ReverseTheString___withforloop {

	public static void main(String[] args) {
//		Scanner sc = new Scanner(System.in);
//		System.out.println("enter the String value");
//		String original = sc.next();
//		System.out.println("Given String value is  " + original);
		String original="mom";
		String reverse="";
		
		for(int i=original.length()-1;i>=0;i--) 
		{
		char t=	original.charAt(i);
		reverse=reverse+t;		
		}
		System.out.println(" reverse String is "+reverse);
		
		System.out.println(original.equals(reverse) ? "Palindrome" : "Not a Palindrome");
//		
//		if(reverse.equalsIgnoreCase(original)) {
//			System.out.println("String is paildrome method");
//		}
//		else {
//			System.out.println("not pailodrome");
//		}
//	
//*******************************************************************************************************************//
	Scanner sc2=new Scanner(System.in);
	System.out.println("enter the string value ");
	String data=sc2.next();
	
	System.out.println("the given string is "+data);
	
	String reversestring="";
	
	for(int j=data.length()-1;j>=0;j--) {
		char text=data.charAt(j);
		reversestring=reversestring+text;
		}
		System.out.println("reverse string is "+reversestring);
		
		
		if(reversestring.equalsIgnoreCase(data)) {
			System.out.println("the given string is pailondrom");
			
		}
		else {
			System.out.println("the give string is not pailondrom ");
		}
	
	
	
	
	
	}
		
		
		
		
		
		
	}

