package casting________________________14;

public class Upcasting1 {
	
	
	public void odi() {
		
		System.out.println("TEAM INDIA");
	}
    public void odi2() {
    	
    	System.out.println("TEAM NEWZELAND");
    }
}
