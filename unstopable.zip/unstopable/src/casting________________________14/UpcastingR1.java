package casting________________________14;

public class UpcastingR1 {

	public void name1() {
		System.out.println("parrent class1");
	}
	
	public void name2() {
		System.out.println("parent class2");
	}
}
