package casting________________________14;

public class UpcastingcallingR1 {
	
	public static void main(String[] args) {
		UpcastingR1 YR=new UpcastingR1();
		YR.name1();// parent class calling
		YR.name2();
		System.out.println("====================");
		UpcastingR2 YR1=new UpcastingR2();
		YR1.name1();// child class calling
		YR1.name2();
		System.out.println("=======================");
		
		UpcastingR1 YR2=new UpcastingR2();// mixing class calling-- child class
		YR2.name1();
		YR2.name2();
		
		System.out.println("======================");
	
	
		
	}

}
