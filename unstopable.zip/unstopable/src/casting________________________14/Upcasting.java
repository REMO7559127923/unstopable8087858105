package casting________________________14;

public class Upcasting {
	
	
	public static void main(String[] args) {
		
		Upcasting1 A1=new Upcasting1();
		A1.odi();
		A1.odi2();
		System.out.println("========================");
		Upcasting2 A2=new Upcasting2();
		A2.odi();
		A2.odi2();
		System.out.println("========================");
		
		Upcasting1 A3=new Upcasting2();
		A3.odi();
		A3.odi2();
	  //  A3.odi3();   ---- which is not eligible for upcasting
		System.out.println("========================");
		
		
	}

}
