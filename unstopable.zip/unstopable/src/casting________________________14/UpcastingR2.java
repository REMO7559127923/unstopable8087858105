package casting________________________14;

public class UpcastingR2 extends UpcastingR1
{
	
	public void name1() {
		System.out.println("child class1");
	}
  public void name2() {
	  
	  System.out.println("child class 2");
  }
}
