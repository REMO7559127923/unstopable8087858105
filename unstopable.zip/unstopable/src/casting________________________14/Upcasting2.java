package casting________________________14;

public class Upcasting2 extends Upcasting1{
	
public void odi() {
		
		System.out.println("TEAM pakistan");
	}
    public void odi2() {
    	
    	System.out.println("TEAM england");
    }
     public void odi3()
     {
    	 System.out.println("team afganisthan"); // own method
     }
}
