package casting________________________14;

public class DowncastingR1 {
 public void name4() {
	 System.out.println("down class child");
 }
 
 public void name5() {
	 System.out.println("down class child");
 }
}
