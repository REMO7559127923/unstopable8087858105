package array_study___________________17;

public class Array_study02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		

	}

}
