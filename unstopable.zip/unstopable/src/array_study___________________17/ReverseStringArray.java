package array_study___________________17;

public class ReverseStringArray {
    public static void main(String[] args) {
        String[] names = {"Alice", "Bob", "Charlie", "David", "Eve", "Frank"};
        
        // Initialize two pointers for swapping elements
        int left = 0;
        int right = names.length - 1;
        
        // Swap elements until the pointers meet in the middle
        while (left < right) {
            // Swap the elements at left and right indices
            String temp = names[left];
            names[left] = names[right];
            names[right] = temp;
            
            // Move the pointers towards each other
            left++;
            right--;
        }
        
        // Print the reversed array
        System.out.println("Reversed Array:");
        for (String name : names) {
            System.out.print(name + " ");
        }
    }
}


