package array_study___________________17;

public class Array_stdy01 {

	public static void main(String[] args) {
		String [] city= new String[5];// one dimesional array method
		int []R=new int[6];
		R[0]=10;
		R[1]=11;
		R[2]=12;
		R[3]=13;
		R[4]=14;
		city[0]="Mumbai";
		city[1]="Pune";
		city[2]="Delhi";
		city[3]="Nagpur";
		city[4]="sambhajinagar";
				
		System.out.println("==============================");// forword 
		for(int i=0;i<=city.length-1;i++)// city 
		{
		System.out.println(city[i]);
		}
		System.out.println("=========================");
		for(int i=0;i<=R.length-1;i++)// index number
		{
		System.out.println(R[i]);
		}
		System.out.println("=========================");
		
//		//=============================//
		//reverse order//
		for(int i=city.length-1;i>=0;i--)
		{
		System.out.println(city[i]);
		}
		System.out.println("==============================");
		for(int i=R.length-1;i>=0;i--)
		{
		System.out.println(R[i]);
		}
		
		
		

	}

}
