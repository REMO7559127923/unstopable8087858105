package array_study___________________17;

public class Array_study {
	
	
	
	public static void main(String[] args) {
		int rollNo=10;
		//use array to store multiple information--> homogeneous
		//array declaration
		int rn[]= new int[10];// conditional operator as per capacity
		//array initialization
		rn[0]=10;
		rn[1]=11;
		rn[2]=12;
		rn[3]=13;
		rn[4]=14;
		//array usage
		//System.out.println(rn); this should not be used to print
		System.out.println(rn[0]);
		System.out.println(rn[1]);
		System.out.println(rn[2]);
		System.out.println(rn[3]);
		System.out.println(rn[4]);
		System.out.println(rn[5]);
		System.out.println(rn[6]);
		System.out.println(rn[7]);
		System.out.println(rn[8]);
		System.out.println(rn[9]);// its not smart work <-------
		
		
		
		
		
		System.out.println("=========================");
		// use of static for loop to print array
		for(int i=0;i<=8;i++)//0,1,2,3,4 for(int i=0// intialisation;i<=8//declration;i++=updation)
		{
		System.out.println(rn[i]);
		}
		System.out.println("=========================");
		
		for(int i=0; i<=rn.length-1;i++)
		{
		System.out.println(rn[i]);
		}
		System.out.println("=========================");
		
		
		
	}

}
