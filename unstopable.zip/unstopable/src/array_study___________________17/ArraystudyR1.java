package array_study___________________17;

import java.lang.reflect.Array;

public class ArraystudyR1 {
	
public static void main(String[] args) {
	
	   int[] YR=new int [4];
	   YR[0]=10;
	   YR[1]=20;
	   YR[2]=30;
	   YR[3]=40;
	   
	   System.out.println("array integral form "+YR.length);
	  
	 
	   
	   for(int i=0;i<=3;i++)// forward order-- static
		   
	   {
		   System.out.println(YR[i]);
	   }
	   
	
	   
	   for(int i=3;i>=0;i--)// reverse order
		   
	   {
		   System.out.println(YR[i]);
	   }
	   
	   
	
  for(int i=0;i<=YR.length-1;i++)// forward order --- dynamic
		   
	   {
		   System.out.println(YR[i]);
	   }
	   
	int RollNo[]=new int[6];
	
	RollNo[0]=10;
	RollNo[1]=30;
	RollNo[2]=60;
	RollNo[3]=20;
	RollNo[4]=90;
	RollNo[5]=40;
	
	System.out.println(RollNo[2]);
	
	//===========================//
	int RollNo1[]= {1,2,3,4,5};
	System.out.println(RollNo1[4]);

	   
	   
	   
	//------------------------------------------//
    
	char [] grade= {'A','D','B','C'};
	int [] run= {14,13,34,54,90,199};
	String name[]= {"Sachin", "Virat","Rohit","Hardik"};
	

	for(int i=0;i<=name.length-1;i++)
	{
	System.out.println(name[i]);
	}

}
}
