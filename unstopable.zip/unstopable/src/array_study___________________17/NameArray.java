package array_study___________________17;

public class NameArray {
	public static void main(String[] args) {
		String[] names = { "Rahul", "Sachin", "Vikas", "Kanhaiya" };

		for (String name : names) {
			char firstLetter = name.charAt(0);
			char lastLetter = name.charAt(name.length() - 1);
			System.out.println("Name: " + name);
			System.out.println("First Letter: " + firstLetter);
			System.out.println("Last Letter: " + lastLetter);
			System.out.println();
		}

		String[] givennames = { "renuka", "jyoti", "rupali", "vinod" };

		for (String flll : givennames) {
			char firstl = flll.charAt(0);
			char lastl = flll.charAt(flll.length()-1);

			System.out.println("given array list names is  " + flll);
			System.out.println("the first letter of " + firstl);
			System.out.println("the last letter of " + lastl);

		}

	}
}
