package array_study___________________17;

public class FindMinMaxInArray {
    public static void main(String[] args) {
        int[] numbers = {7, 12, 5, 18, 3, 1};
        
        // Initialize min and max to the first element of the array
        int min = numbers[0];
        int max = numbers[0];
        
        // Iterate through the array to find the minimum and maximum elements
        for (int i = 1; i < numbers.length; i++) {
            if (numbers[i] < min) {
                min = numbers[i];
            } else if (numbers[i] > max) {
                max = numbers[i];
            }
        }
        
        System.out.println("Minimum Element: " + min);
        System.out.println("Maximum Element: " + max);
        
        int[] givennumber= {22, 44, 77, 99, 0,100,-5};
        // intialise the array min and max 
        int min1=givennumber[0];
        int max1=givennumber[0];
        for(int j=1;j<givennumber.length;j++) {
        	if(givennumber[j]>min1) {
        		min1=givennumber[j];
        	}
        	else if(givennumber[j]<max1) {
        		max1=givennumber[j];
        		
        	}
        }
        System.out.println("the minimum given number : "+min1);
        System.out.println("the maximum given number : "+max1);
        
        
    }
}

