package datastudy_______________2;

public class Rev_datastudy {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		System.out.println("========================");
		String name="rahul";// variable declaration
		System.out.println("my name is  "+name);
		System.out.println("=========================");
		
		byte a;
		a=124;
		System.out.println("byte value is "+a);
		
		long mobileno=8624062433l;
		
		System.out.println("mobile number is "+mobileno);
		
		float avarage=75.25f;
		
		System.out.println("the value "+avarage);
		
		double longdecimalno=123.52525645445d;
		
		System.out.println("double "+longdecimalno);
		
		
		char gender ='M';
		System.out.println(" my gender is "+gender);

	}

}
