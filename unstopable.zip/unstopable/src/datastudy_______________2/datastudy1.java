package datastudy_______________2;

public class datastudy1 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
         
		
		//=========NON PERIMATIVE DATA TYPE========/
		
		System.out.println("===================");
		
		String name="RAHUL VASANT BADGUJAR";
		
		System.out.println("my name is "+name);
		
		System.out.println("===================");
		
		
		String studyname="i am tester";
		
		System.out.println("my studied is "+studyname);
		
		System.out.println("===================");
		
		
		//=========PERIMATIVE DATA TYPE========//
		
		// ******number with non decimal*******
		byte a;
		a = 127;
		System.out.println("my byte value is "+a);
		
		System.out.println("===================");
		
		int b;
		b=1234567890;
		System.out.println("my serial number is "+b);
		
		System.out.println("===================");
		
		long c;
		c=8624062433l;
		System.out.println("my mobile number is "+c);
		
		System.out.println("===================");
		
		//*******number with decimal*********
		
		float d;
		d=81.22f;
		System.out.println("my decimal number is "+d);
		
		System.out.println("===================");
		
		double e;
		e=123.12556545654555455d;
		System.out.println(" my long decimal number is "+e);
		
		System.out.println("===================");
		
		//*******for single character*********
		char f;
		f='M';
		System.out.println(" MY GENDER IS  "+f);
		
		System.out.println("===================");
		
		//*******for true or false*********
		boolean g;
		g=true;
		System.out.println(" all the information is "+g);
		
		System.out.println("===================");
		
		
	}



	
	
	
	
	
	

}
