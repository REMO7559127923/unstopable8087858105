package A9_Advanced_javalogical;

public class FileOrganizerDone {
	
    public static void main(String[] args) {
    	
        String[] files = {"photo.jpg", "report.pdf", "movie.mp4", "notes.txt", "slide.pptx", "banner.png"};

        for (String file : files) {
            System.out.print(file + ": ");

            if (file.endsWith(".jpg") || file.endsWith(".png")) {
                System.out.println("Image");
            } else if (file.endsWith(".pdf") || file.endsWith(".doc")) {
                System.out.println("Document");
            } else if (file.endsWith(".mp4") || file.endsWith(".mkv")) {
                System.out.println("Video");
            } else {
                System.out.println("Other");
            }
        }
    }
}



