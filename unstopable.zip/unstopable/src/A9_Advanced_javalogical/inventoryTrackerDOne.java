package A9_Advanced_javalogical;

public class inventoryTrackerDOne {
	public static void main(String[] args) {
		 String[] items = {"Laptops", "Keyboards", "Monitors", "Mice"};
		
		 int[] stock = {0, 15, 25, 5};
		 
		 for(int i=0 ; i<items.length;i++) {
			 
			 if(stock[i]==0) {
				 System.out.println("Out of stock ");
			 }
			 else if (stock[i]<=20) {
				 System.out.println(" low stock ");
			 }
			 else {
				 System.out.println(" in stock ");
			 }
		 }
		
		
	}

}
