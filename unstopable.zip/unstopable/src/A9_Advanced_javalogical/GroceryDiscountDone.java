package A9_Advanced_javalogical;

public class GroceryDiscountDone {
public static void main(String[] args) {
	
	String [] input= {"milk","sugar","rice","wheat","oil"};
	double [] price= {80, 150, 600, 300, 800};
	/*If the item's price is below 100, no discount applies.
	If the price is between 100 and 500, apply a 10% discount.
	If the price is above 500, apply a 20% discount.
	Print the item name, original price, discount, and final price.*/

	
	System.out.printf("%-15s %-10s %-10s %-10s%n","input", "Price", "discount", "Final Price");
	
	
	for(int i=0;i<input.length;i++) {
		double discount=0;
		if(price[i]>100 && price[i]<=500)
			
		{
			discount=price[i]*0.10;
		}
		else if(price[i]>500) {
			discount=price[i]*0.20;
			
		}
		double finalprice=price[i]-discount;
		System.out.printf("%15s %-10s %-10s %-10s%n",input[i],price[i],discount,finalprice );
		
		
		
		
	}
	
	
	
	
	
	
}
}
