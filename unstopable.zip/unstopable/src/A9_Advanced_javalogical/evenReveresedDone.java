package A9_Advanced_javalogical;

public class evenReveresedDone {
    public static void main(String[] args) {
        String str = "Java is an amazing programming language";
        System.out.println("Original Sentence: " + str);

        String[] input = str.split(" ");
        StringBuilder result = new StringBuilder();

        for (String logic : input) {
            if (logic.length() % 2 == 0) {
                result.append(logic.toUpperCase());
            } else {
                result.append(new StringBuilder(logic).reverse());
            }
            result.append(" ");
        }

        System.out.println("Modified Sentence: " + result.toString().trim());
    }
}


