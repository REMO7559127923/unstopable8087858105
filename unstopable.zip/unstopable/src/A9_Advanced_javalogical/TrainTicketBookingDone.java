package A9_Advanced_javalogical;

public class TrainTicketBookingDone {
	public static void main(String[] args) {
		
		
		String [] trains= {"kashi","jhelam","pawan","gitanjali"};
		int availableseat []= {10,20,30,42};
		
		
		
		
		for(int i=0;i<trains.length;i++) {
			System.out.println(trains[i]+   ":");
			
			if (availableseat[i] > 40) {
			    System.out.println("70% chance ");
			} else if (availableseat[i] >= 30) {
			    System.out.println("50% chance ");
			} else if (availableseat[i] < 20) {
			    System.out.println("no chance ");
			}

			
			
		}
	}

}
