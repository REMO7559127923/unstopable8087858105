package A9_Advanced_javalogical;

public class PasswordValidator {
	
	    public static void main(String[] args) {
	    	String [] str={"abc123", "Abcdefgh", "Password1!", "helloWORLD", "test@", "WeakPass1", "Pass#123"};
	        
	        
	        for(String logic:str){
	           String msg;
	          
	          if(logic.length()<8){
	            msg="Password should minimum 8 Character ";
	          }  else if(logic.matches(".*[!@#$%^&*()].*")){
	            msg="very strong password ";
	          }
	            else if(logic.matches(".*[aZ-zA].*")){
	              msg="strong password";
	            }
	            else{
	              msg="weak password";
	            }
	          
	                System.out.println("password for "+logic+"  : "+msg);

	          
	        }
	        
	        
	        
	    }
	}


