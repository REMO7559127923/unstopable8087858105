package collection_______18;

import java.util.ArrayList;

public class Iterator {//cursor

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList al = new ArrayList(); // created object of arryList
		al.add("Velocity");
		al.add(123);
		al.add('M');
		al.add("Velocity");
		al.add(123.123f);
		al.add(null);
		al.add(null);
		al.add(true);
		al.add(false);
		System.out.println(al);
		al.add(2, 456);
		System.out.println(al);
		System.out.println(al.size());
		System.out.println(al.contains("Pune"));
		;
		System.out.println(al.contains("Velocity"));
		System.out.println(al.get(9));
		System.out.println(al.get(3));
//System.out.println(al.get(22));-->IndexOutOfBoundsException
		System.out.println(al.indexOf(123.123f));
		System.out.println(al.lastIndexOf("Velocity"));
		System.out.println(al.isEmpty());
		System.out.println(al.remove(true));
		System.out.println(al);
		System.out.println(al.remove(0));
		System.out.println(al);
//al.clear();
		System.out.println(al);
		for (Object m : al) {
			System.out.println(m);
		}
		 ArrayList<String>al1= new ArrayList<>();
		
		 al1.add("Virat");
		 al1.add("Rohit");
		 al1.add("DK");
		 al1.add("Surya");
		 al1.add(null);
		
		
		 System.out.println(al1);
		 for(String r:al1) {
			 System.out.println(r);
		 }
	}

}
