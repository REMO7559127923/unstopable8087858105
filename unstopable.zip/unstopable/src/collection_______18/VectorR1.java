package collection_______18;

import java.util.Vector;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.ListIterator;

public class VectorR1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Vector v=new Vector();
		v.add("Hi");
		v.add('M');
		v.add(123);
		v.add(true);
		v.add(null);
		v.add(null);
		v.add("Hi");
		v.add(123.33f);
		
		System.out.println(v);
		System.out.println(v.get(3));
		System.out.println(v.remove(1));
		System.out.println(v);
		System.out.println(v.contains(true));
		System.out.println(v.capacity());
		v.add("hello");
		v.add(false);
		v.add(100);
		v.add(233);
		v.add('J');
		System.out.println(v);
		System.out.println(v.capacity());
		System.out.println(v.size());
		
		//==================iterator=============//
		Iterator itr=v.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
		System.out.println("===========================");
		//===========for loop====================//
		for(int i=0;i<=v.size()-1;i++) {
			System.out.println(v.get(i));
		}
		System.out.println("=============================");
		//===========each loop=====================//
		for(Object o:v) {
			System.out.println(o);
		}
		System.out.println("================================");
		//==========List Iterator==================//
		ListIterator<Object> litr=v.listIterator();
		while(litr.hasNext()) {
			System.out.println(litr.next());
		}
		System.out.println("==================================");
		//==============Enumeration================//
		Enumeration<Object> enmu=v.elements();
		while(enmu.hasMoreElements()) {
			System.out.println(enmu.nextElement());
		}
		System.out.println("=====================================");
	}

}
