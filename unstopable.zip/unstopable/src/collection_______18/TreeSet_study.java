package collection_______18;

import java.util.TreeSet;

public class TreeSet_study {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	TreeSet<Object> ts = new TreeSet<>();
	
	ts.add(7);
	ts.add(2);
	ts.add(8);
	ts.add(6);
	ts.add(1);
	//ts.add(3);
	ts.add(5);
	ts.add(4);
	//ts.add(null);// we get--- java.lang.NullPointerException
	//ts.add("pune");// we get----java.lang.ClassCastException
	
	
	System.out.println(ts);
	System.out.println(ts.first());
	System.out.println(ts.floor(3));
	System.out.println(ts.higher(7));
	System.out.println(ts.higher(8));// we will get when highest number not present null value
	System.out.println("======================================");
	System.out.println(ts.pollFirst());
	System.out.println("======================================");

	System.out.println(ts.pollLast());
	
	
	}

}
