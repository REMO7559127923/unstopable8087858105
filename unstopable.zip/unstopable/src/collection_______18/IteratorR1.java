package collection_______18;

import java.util.ArrayList;
import java.util.ListIterator;
import java.util.Iterator;


public class IteratorR1 {

	public static void main(String[] args) {
		ArrayList<Integer> al2= new ArrayList<>();
		
		al2.add(20);
		al2.add(40);
		al2.add(60);
		al2.add(80);
		al2.add(100);
		al2.add(120);
		al2.add(140);
		al2.add(160);
		System.out.println(al2);
		System.out.println(al2.get(0));
		System.out.println(al2.get(1));
		System.out.println(al2.get(2));
		System.out.println(al2.get(3));
		System.out.println(al2.get(4));
		System.out.println(al2.get(5));
		System.out.println(al2.get(6));
		System.out.println(al2.get(7));
		System.out.println("===========for loop(static)===================");
		//===================for loop(static)=============================
          for(int i=0;i<=7;i++) 
           {
            	System.out.println(al2.get(i));
            }
            System.out.println("===========for loop(dynamic)===================");
    		//===================for loop(dynamic)=============================
           
            for(int i=0;i<=al2.size()-1;i++) 
            {
            	System.out.println(al2.get(i));
            }
            System.out.println("===========for each====================");
    		//===================for each=============================
    		for(Integer a:al2)
    		{
    		System.out.println(a);
    		}
    		System.out.println("===========iterator====================");
    		//===================iterator=============================
    		Iterator<Integer> it = al2.iterator();
    		while(it.hasNext())
    		{
    		System.out.println(it.next());
    		}
    		System.out.println("===========List iterator====================");
    		//===================List iterator=============================
    		ListIterator<Integer> li = al2.listIterator();
    		while(li.hasNext())
    		{
    		System.out.println(li.next());
    		}

	}

}
