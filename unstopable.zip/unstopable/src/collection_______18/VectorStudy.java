package collection_______18;

import java.util.Enumeration;
import java.util.ListIterator;
import java.util.Vector;
import java.util.Iterator;

public class VectorStudy {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vector v=new Vector();
		v.add("Hi");
		v.add('M');
		v.add(123);
		v.add(true);
		v.add(null);
		v.add(null);
		v.add("Hi");
		v.add(123.33f);
		System.out.println(v);
		System.out.println(v.get(3));
		System.out.println(v.remove(1));
		System.out.println(v);
		System.out.println(v.contains(true));
		System.out.println(v.capacity());
		System.out.println(v.size());
		v.add("hello");
		v.add(false);
		v.add(100);
		v.add(233);
		v.add('J');
		System.out.println(v);
		System.out.println(v.capacity());
		System.out.println(v.size());
		//for loop, for each, iterator, listIterator, enumeration
		System.out.println("=======for loop=====================");
		for(int i=0;i<=v.size()-1;i++)
		{
		System.out.println(v.get(i));
		}
		System.out.println("=======for each=====================");
		for(Object c:v)
		{
		System.out.println(c);
		}
		System.out.println("=======iterator=====================");
		Iterator <Object> vt = v.iterator();
		while(vt.hasNext())
		{
		System.out.println(vt.next());
		}
		System.out.println("=======ListIterator=====================");
		ListIterator<Object> vl = v.listIterator();
		while(vl.hasNext())
		{
		System.out.println(vl.next());
		}
		System.out.println("=======Enumeration=====================");
		Enumeration<Object> ve = v.elements();
		while(ve.hasMoreElements())
		{
		System.out.println(ve.nextElement());
		}

	}

}
