package collection_______18;

import java.util.HashSet;
import java.util.Iterator;

public class Hasset__R1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	HashSet<Object> hs=new HashSet<>();
	

	hs.add(1234);
	hs.add('M');
	hs.add(12.12f);
	hs.add(true);
	hs.add(null);
	hs.add(null);
	
	System.out.println(hs);
	//hs.clear();
	System.out.println(hs.isEmpty());
	
	Object hs1=hs.clone();
	System.out.println(hs1);
	System.out.println(hs.contains(1234));
	System.out.println(hs.remove('M'));
	System.out.println(hs);
	System.out.println(hs.size());
	//set interfaced doesn't cantains  capacity method		
	//for loop cant be used in set-coz of order of insertion not allowed
		
	//=================for each loop=======================//
	for(Object o:hs) {
		System.out.println(o);
	}
		System.out.println("==================================");
		
    //================iterator=============================//
		Iterator<Object> itr=hs.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
	}

}
