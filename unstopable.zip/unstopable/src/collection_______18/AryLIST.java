package collection_______18;

public class AryLIST {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
