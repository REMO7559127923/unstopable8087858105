package collection_______18;

import java.util.ArrayList;
import java.util.Iterator;

public class AArrayLIst001 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList Bl=new ArrayList();
		Bl.add("RAhul");
		Bl.add("Jan-22");
		Bl.add(100);
		Bl.add(99.99);
        Bl.add("renuka");
        Bl.add("RAhul");
        Bl.add(null);
        Bl.add(null);
        
        
        
        System.out.println(Bl);
        System.out.println("=============================");
        System.out.println(Bl.size());
        System.out.println("=============================");
        System.out.println(Bl.indexOf("RAhul"));
        System.out.println("=============================");
        System.out.println(Bl.lastIndexOf("RAhul"));
        System.out.println("=============================");
        System.out.println(Bl);
        Bl.set(2, 'A');
        System.out.println("=============================");
        System.out.println(Bl);
        Bl.remove(2);
        System.out.println("=============================");
        System.out.println(Bl);
        System.out.println("=============================");
        //========= iterator ==========//
        Iterator itr= Bl.iterator();
        while(itr.hasNext()) {
        	System.out.println(itr.next());
        }
        System.out.println("=============================");
        //============forloop==========//
        for(int i=0;i<=Bl.size()-1;i++) {
        	System.out.println(Bl.get(i));
        }
        System.out.println("=============================");

       //===========each loop==========//
        for(Object o:Bl) {
        	System.out.println(o);
        }
        System.out.println("=============================");

		

	}

}
