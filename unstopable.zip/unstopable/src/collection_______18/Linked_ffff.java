package collection_______18;

import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Iterator;

public class Linked_ffff {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LinkedList<Object> ll= new LinkedList<>();
		ll.add("RAHUL");
		ll.add("Velocity");
		ll.add(1234);
		ll.add(null);
		ll.add(null);
		ll.add('M');
		ll.add(123.123f);
		ll.add(true);
		ll.add(false);
		ll.add(123);
		System.out.println(ll);
		System.out.println(ll.size());
		System.out.println(ll.contains(null));
		System.out.println(ll.element());
		System.out.println(ll);
		System.out.println(ll.get(9));
		System.out.println(ll.getFirst());
		System.out.println(ll.getLast());
		System.out.println(ll.offerFirst("Pune"));
		System.out.println(ll);
		System.out.println(ll.offerLast("MH"));
		System.out.println(ll);
		System.out.println(ll.peek());
		System.out.println(ll.poll());
		System.out.println(ll);
		System.out.println(ll.peekFirst());
		System.out.println(ll.peekLast());
		System.out.println(ll.pollFirst());
		System.out.println(ll);
		System.out.println(ll.pollLast());
		System.out.println(ll);
		System.out.println(ll.pop());
		System.out.println(ll);
		System.out.println(ll.pop());
		System.out.println(ll.set(3, "Velocity"));
		System.out.println(ll);
		//for, for each, iterator, ListIterator
		System.out.println("==========for loop===============");
		System.out.println("=========for each=================");
		for(Object l:ll)
		{
		System.out.println(l);
		}
		System.out.println("==========iterator=============");
		Iterator<Object> it = ll.iterator();
		while(it.hasNext())
		{
		System.out.println(it.next());
		}
		System.out.println("==========List-iterator=============");
		ListIterator<Object> li = ll.listIterator();
		while(li.hasNext())
		{
		System.out.println(li.next());
		}
	}

}
