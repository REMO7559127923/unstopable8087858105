package stringstudy;

public class StringR1 {
	public static void main(String[] args) {
		// length
		String s="rahularya";
		System.out.println("String length is "+s.length());
		// length
		String q="a p p l e 1 2 3";
		System.out.println("String length is space between "+q.length());
		// upper case
		System.out.println("String length is UPPER CASE "+q.toUpperCase());
		// lower case 
		System.out.println("String length is LOWER CASE "+q.toLowerCase());
		// equal method
		 String D="Pune";
	     String J="Pune";
	     String A=new String("Pune");
	     String B=new String("PUNE");
	     String C=new String("PUnr");
	         
	         System.out.println(D==A);// false because String type
	         System.out.println(D==J);// same string type
	         System.out.println(D==B);// not equal valid
	         
	         System.out.println(D==C);//not eqal valid
	         
	         
	         
	         
	         System.out.println();
	     // type with "equal"
	         System.out.println(D.equals(J));//same string type
	         System.out.println(D.equals(A));//valid data type
	         System.out.println(D.equals(B));//in valid data type
	         System.out.println(D.equals(C));//in valid data type
	}

}
