package constructor______________6;

public class Revise_constructor {
	
int a;// varibale declaration
float b;
long c;
double d;




public Revise_constructor(){//constructor without parameter
	a=10;
	b=5.5f;
	c=8624062433l;
	d=123.3625546648555d;// variable intialization
	System.out.println("Running user defined without parameter constructor");
}
public Revise_constructor(int A) // constructor with single parameter
{
	a=A;
	//b=B;
	//c=C;
	//d=D
	System.out.println("Running user defined with one parameter constructor");
}
public Revise_constructor(int A,float B) // constructor with double parameter
{
	a=A;
	b=B;
	System.out.println("Running user defined with two parameter constructor");
}
public Revise_constructor(int A,float B,long C) // constructor with three parameter
{
	a=A;
	b=B;
	c=C;
	System.out.println("Running user defined with three parameter constructor");
	
}
public Revise_constructor(int A,float B,long C,double D) { // constructor with four parameter
	a=A;
	b=B;
	c=C;		
	d=D;
    System.out.println("Running user defined with four parameter constructor");		
	
}

public static void main(String[] args) {
	Revise_constructor RR=new Revise_constructor();// already define value
		RR.add();
	Revise_constructor RR1=new Revise_constructor(20);
	RR1.add();
	Revise_constructor RR2=new Revise_constructor(10, 5.5f);
	RR2.add();
	Revise_constructor RR3=new Revise_constructor(10, 2.3f, 100000000l);
	RR3.add();
	Revise_constructor RR4=new Revise_constructor(10, 5.3f, 10000000l, 18.3332415354d);
	RR4.add();
}











public void add() {// math operation
	double addition=a+b+c+d;
	
	System.out.println("the addition value is "+addition);
}
}
