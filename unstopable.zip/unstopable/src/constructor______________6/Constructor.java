package constructor______________6;

public class Constructor {
	int a;// variable declaration
	int b;// variable declaration
	int c;// variable declaration
	int d;// variable declaration
		
	public Constructor()       // public   + class name ()
	{
		a=10;
		b=20;
		c=30;
		
		System.out.println(" running zero parmeter CONSTRUCTOR");
		
	}
	
	public Constructor(int A,int B)  // public   + class name (intialize para)
	{
		a=A;
		b=B;
			
	}
	
	public Constructor(int A,int B,int C) // public   + class name (intialize para)
	{
		a=A;
		b=B;
		c=C;
		
	}	
	
	public Constructor(int A,int B,int C,int D) // public   + class name (intialize para)
	{
		a=A;
		b=B;
		c=C;
	    d=D;	
   }
	
	public static void main(String[] args)// CREATE NEW OBJECT AS PER PARAMETER
	{
		Constructor RR=new Constructor();
		RR.addition();
		
		Constructor RR1=new Constructor(10, 20);
		RR1.addition();
		
		Constructor RR2= new Constructor(50, 50, 50);
		RR2.addition();
		
		Constructor RR3= new Constructor(50, 50, 50, 50);
		RR3.addition();
              
		
		
	}
	
	public void addition()// MATH OPERATION FORMULA SET
	{
		 
		int addition1=a+b+c+d;
		System.out.println(" the addition is "+addition1);
		
	}
	
	
	
}

