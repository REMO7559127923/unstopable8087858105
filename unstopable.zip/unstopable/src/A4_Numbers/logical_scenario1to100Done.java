package A4_Numbers;

public class logical_scenario1to100Done {
	public static void main(String[] args) {
		
		for(int i=0;i<=100;i++) {
			StringBuilder sb=new StringBuilder();
			
			if(i%2==0) {
				sb.append("hello");
			}
			if(i%7==0) {
				if(sb.length()>0) sb.append(" ");
				sb.append("world");
			}
			
			if(i%8==0) {
				if(sb.length()>0) sb.append(" ");
				sb.append("my country");
			}
			if(i%9==0) {
				if(sb.length()>0) sb.append(" ");//
				sb.append("india");
			}
			// for print itself 
			if(sb.length()==0) {
				System.out.println(i);
			}
			else {
			System.out.println(sb.toString());
			}
			
			
			
			
		}
		
		
	}

}
