package A4_Numbers;

public class Armstrong_number {
	public static void main(String[] args) {
		
		int number=153;
		int sum=0;
		
		
		for(int i=number;i>0;i=i/10) {
			int reminder=i%10;
			
			sum=sum+(reminder*reminder*reminder);
			
			
		}
		System.out.println("the given number sum is "+sum);
		
		if(number==sum) {
			System.out.println("the given number is Armstrong");
		}
		else {
			System.out.println(" the given number is Non Armstrong");
		}
	}

}
