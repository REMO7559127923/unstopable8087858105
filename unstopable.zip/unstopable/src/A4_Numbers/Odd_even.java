package A4_Numbers;

public class Odd_even {
	public static void main(String[] args) {
		int number=7;
		if(number%2==0) {
			System.out.println("the given number is even");
		}
		else {
			
			System.out.println("the given number is odd");
		}
	}

}
