package A4_Numbers;

public class multiplication_without {
	public static void main(String[] args) {
		
	
	int a=3;
	int b=5;
	int sum=0;
	
	for(int i=1;i<=b;i++) {
		sum =sum+a;
	}
	System.out.println("the given multiplication is "+sum);
	}
}
