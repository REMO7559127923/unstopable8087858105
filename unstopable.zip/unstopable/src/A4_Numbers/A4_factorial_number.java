package A4_Numbers;

public class A4_factorial_number {
public static void main(String[] args) {
	int number=6;
	int fact=1;
	for(int i=number;i>0;i--) {
		fact=fact*i;
		
	}
	System.out.println("the given number factorial is "+fact);
}
}
