	package A4_Numbers;

import java.text.NumberFormat;
import java.util.Locale;

public class number_torupees {
	public static void main(String[] args) {
		
		long number=123456789;
		
		NumberFormat logic = NumberFormat.getCurrencyInstance(new Locale("en", "IN"));
		String result = logic.format(number).replace("₹", "Rs.");
		System.out.println(" the given number is convert to indian currency"+result);
		
		
		
		
		
		
//		NumberFormat logic = NumberFormat.getCurrencyInstance(new Locale("en", "IN"));
//		
//		String rupees = logic.format(number).replace("₹", "Rs.");
//		
//		System.out.println(" the given number to rupees is : "+rupees);
	}

}
