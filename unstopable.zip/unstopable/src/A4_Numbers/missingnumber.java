package A4_Numbers;

public class missingnumber {
	public static void main(String[] args) {
		
		int [] number= {1,2,3,4,5,7};
		
		
		int n=number.length+1;
		
	int	expectedsum=n*(n+1)/2;
	
	int actualsum=0;
	
	for(int logic:number) {
		actualsum+=logic;
	}
		System.out.println("the given missing number "+(expectedsum-actualsum));
	}

}
