package A4_Numbers;

public class TableToWord {
    public static void main(String[] args) {
        // Input numbers
        int num =13 ; // Example input, can be replaced with any number

        // Check if the number belongs to the 2-table or 7-table
        if (num % 2 == 0 && num % 7 == 0) {
            System.out.println("enter the number");
        } else if (num % 2 == 0) {
            System.out.println("hello");
        } else if (num % 7 == 0) {
            System.out.println("world");
        } else {
            System.out.println("Not in 2-table or 7-table");
        }
    }
}



