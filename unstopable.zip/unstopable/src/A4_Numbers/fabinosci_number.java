package A4_Numbers;

public class fabinosci_number {
	
	public static void main(String[] args) {
		int number=12;
		
		int a=0;
		int b=1;
		
		System.out.println(" the given number "+number+" fabinoscci is :");
		
		for(int i=0;i<number;i++) {
			System.out.println(a+" ");
			
			// swap with temp
			int temp=a;
					a=b;
			b=b+temp;
		}
		
		
	
		
		
		
	}

}
