package A1_Duplicateset;

import java.util.HashSet;
import java.util.Set;

public class DuplicateCharcter {
	public static void main(String[] args) {
		String str = "rahulvasantbadgujar";

		char[] input = str.toCharArray();

		Set<Character> unique = new HashSet<>();
		Set<Character> duplicate = new HashSet<>();

		for (char logic : input) {

			if (!unique.add(logic)) {
               duplicate.add(logic);
			}

		}
System.out.println("the given string conatins duplicate charcter is "+duplicate);
	}

}
