package A1_Duplicateset;

import java.util.Scanner;

public class ReverseNumber_withforloop {

	public static void main(String[] args) {
		//num=1234-->4321
		int num=1234;
		//int to String
		String org = Integer.toString(num);
		String rev="";
		for(int i=org.length()-1;i>=0;i--) {
		char t = org.charAt(i);
		rev= rev+t; }
		// System.out.println(rev);
		int revNum = Integer.parseInt(rev);
		System.out.println("Given number is "+num);
		System.out.println("reverse number is "+revNum);
		
		
//		Scanner sc2=new Scanner(System.in);
//		int number=sc2.nextInt(); 
		//isme number diya hai krk scanner use nhi krneka 
		int num2=6789;
		String data=Integer.toString(num2);
		String reverse1="";
		for(int i=data.length()-1;i>=0;i--) {
			char text=data.charAt(i);
			reverse1=reverse1+text;
		}
		int revnumber=Integer.parseInt(reverse1);
		System.out.println("given number is  "+ num2);
		System.out.println("the reverse number is"+revnumber);
		
		
		
		
		
		
		}
	}


