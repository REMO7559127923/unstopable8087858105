package A1_Duplicateset;

import java.util.HashSet;
import java.util.Set;

public class Remove_duplicate_string {
	
	
	public static void main(String[] args) {

		String str="raahul raahul java renuka badgujar";
		String[] input=str.split(" ");
		
		Set<String> unique=new HashSet<>();
		
		for(String logic:input) {
			
		unique.add(logic);
	}
System.out.println(" the given string array after remove dupliacte string is "+unique);
	}}
