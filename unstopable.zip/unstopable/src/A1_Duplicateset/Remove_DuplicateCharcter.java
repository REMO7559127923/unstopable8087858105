package A1_Duplicateset;

import java.util.HashSet;
import java.util.Set;

public class Remove_DuplicateCharcter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str="raahulbadgujar";
		char[] input=str.toCharArray();
		
		
		Set<Character> unique=new HashSet<>();
		for(char logic :input) {
			unique.add(logic);
			
		}
System.out.println(" the given array duplicayr chacter is remove "+unique);
	}

}
