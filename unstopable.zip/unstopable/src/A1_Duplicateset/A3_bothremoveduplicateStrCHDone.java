package A1_Duplicateset;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;




	public class A3_bothremoveduplicateStrCHDone{
	    public static void main(String[] args) {
	        String str = "java java java kya hai drama";
	        char[] chinput=str.toCharArray();

	        // Character-Level Deduplication
	        StringBuilder charResult = new StringBuilder();// ye add karna hai
	        HashSet<Character> unique1 = new HashSet<>();
	        for (char chlogic1 : chinput) {
	            if (unique1.add(chlogic1)) { // Add returns false if character is already in the set // if isliye add kiya hai q ki appnend karna hai
	                charResult.append(chlogic1);
	            }
	        } 

	        // Word-Level Deduplication
	        String[] input = str.split("\\s+"); // Split the string into words
	        LinkedHashSet<String> unique2 = new LinkedHashSet<>();
	        for (String sr : input) {
	        	unique2.add(sr); // Add returns false if word is already in the set
	        }
	        String wordResult = String.join(" ", unique2); // Join the words back into a single string

	        // Print Results
	        System.out.println("Original String: " + str);
	        System.out.println("Character-Level Deduplication: " + charResult.toString());
	        System.out.println("Word-Level Deduplication: " + wordResult);
	    }
	}
