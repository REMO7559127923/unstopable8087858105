package A1_Duplicateset;

import java.util.HashSet;
import java.util.Set;

public class Remove_duplicateNumber {
	
	public static void main(String[] args) {
		int [] number= {1,2,3,5,4,4,4,4,4,4,2,2,2,2,100};
		
		Set<Integer> unique=new HashSet<>();
		
		for(int logic:number) {
			unique.add(logic);
		}
		System.out.println("array after remove dupliacte number is "+unique);
		
	}

}
