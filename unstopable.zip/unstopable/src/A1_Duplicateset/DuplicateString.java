package A1_Duplicateset;

import java.util.HashSet;
import java.util.Set;

public class DuplicateString {

	public static void main(String[] args) {
		
		
		String str="java java raahul raahul renuka badgujar";
		String[] input=str.split(" "); 
		Set<String> unique=new HashSet<>();
		Set<String> duplicate=new HashSet<>();
		
		for(String logic:input) {
			if(!unique.add(logic)) {
				duplicate.add(logic);
			}
		}

		System.out.println(" the given dupliacte string is "+duplicate);

	}

}
