package A1_Duplicateset;

import java.util.HashSet;
import java.util.Set;

public class Duplicate_number {
	
	public static void main(String[] args) {
		
		int []number= {2,1,3,4,5,6,7,8,8,9,12,32,2,2,2,2,2};
		
		
		Set<Integer> unique=new HashSet<>();
		Set<Integer>duplicate=new HashSet<>();
		
		
		
		for(int logic :number) {
			if(!unique.add(logic)) {
				duplicate.add(logic);
			}
		}
		System.out.println("the given dupliacte number is "+duplicate);
	}

}
