package polymorphism_study_____________________13;

public class PolyR1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
           PolyR1 YR=new PolyR1();
           YR.display(7000);
           YR.mul(50, 60);
           YR.sub(1000, 300, 250);
	}

	public void display(int a) {
		
		System.out.println("one parameter "+a);// single parameter 
		
		
	}
	
	public void mul(int a, int b ) {
		
		int multi=a*b;
		System.out.println("two parameter "+multi);// two parameter
		
	}
	public void sub(int a,int b,int c) {
		
		int subtraction=a-b-c;
		
		System.out.println("three parameter "+subtraction);// three parameter
	}
	
	
	
	
	
	
	
	
	
	
}
