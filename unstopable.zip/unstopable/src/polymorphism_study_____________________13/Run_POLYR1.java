package polymorphism_study_____________________13;

public class Run_POLYR1 extends PolyR1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Run_POLYR1 YR=new Run_POLYR1();
        YR.sub(900, 25, 600);
        YR.mul(80, 90);
        YR.display(600);
	}

}
