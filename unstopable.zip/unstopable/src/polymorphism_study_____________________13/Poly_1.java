package polymorphism_study_____________________13;

public class Poly_1 {

	
	
	
	
	public static void main(String[] args) {//def-in compile time polymorphism methode declration going to get binded to 
		                                   //its defination at complition time, based on argument known as polymorphism
		
		Poly_1 RM=new Poly_1();
	
		RM.test1(50);//with one parameter calling
		RM.test1(50, 50);//with two parameter calling
		RM.test1(100, 200, 300);//with three parameter calling
	}
	
	public void test1(int a,int b,int c) {
		int sub=a-b-c;
		System.out.println(" the value of sub "+sub);// with three parameter
		
		
	}
	public void test1(int a,int b) // two parameter
	{
		
	
	int sum = a+b;
	System.out.println("my addition is "+sum);
	}
	
	public void test1(int a)// one parameter
	{
		System.out.println("value of a is  "+a);
		
	}
}
