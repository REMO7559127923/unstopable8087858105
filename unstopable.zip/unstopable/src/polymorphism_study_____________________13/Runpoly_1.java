package polymorphism_study_____________________13;

public class Runpoly_1 extends Poly_1
{
	
	
	
	
public static void main(String[] args) {
	
	
	
	Runpoly_1 SR=new Runpoly_1();// same class object create calling 

	SR.test1(500, 500);// same class object create calling
	SR.test1(1000, 800, 500);
	
	
	Poly_1 SN=new Poly_1();//another class object create calling
	SN.test1(800, 700, 600);
	SN.test1(1000);//another class object create calling
	SN.test1(1000, 1000);// another class object create calling
}

public void test1(int a)
{
	System.out.println(" the value is "+a);
	
}


}
