package exception_____________22;

public class TryCatchFinally {

	public static void main(String[] args) {
		String a=null;
		try
		{
		System.out.println(a.length());
		}
		catch (NullPointerException e)
		{
		System.out.println("a is null");
		}
		finally
		{
		System.out.println("Hi GM all..");
		}
	}

}
