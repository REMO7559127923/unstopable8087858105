package exception_____________22;

public class FinallyBlock {

	public static void main(String[] args) {
		String a="hi";
		try
		{
		System.out.println(a.charAt(10));//risky code
		}
		finally
		{
		System.out.println("Hi GM");
		}
		}
	}

